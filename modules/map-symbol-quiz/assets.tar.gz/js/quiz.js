export const TARGET = 30;
export const FEEDBACK_MS = 700;

const groups = [
  ['city-hall', 'town-hall', 'government', 'court', 'tax-office'],
  ['health-center', 'hospital', 'police', 'police-box'],
  ['school', 'high-school', 'university', 'library', 'museum'],
  ['shrine', 'temple', 'castle', 'monument', 'cemetery'],
  ['factory', 'power', 'lighthouse', 'wind-turbine'],
  ['radio-tower', 'tall-tower', 'chimney', 'wind-turbine'],
  ['major-port', 'local-port', 'fishing-port', 'lighthouse', 'ferry', 'passenger-ship'],
  ['mine', 'quarry', 'entrance', 'well'],
  ['rice', 'field', 'tea', 'orchard', 'mulberry'],
  ['broadleaf', 'conifer', 'bamboo', 'bamboo-grass', 'dwarf-pine', 'wasteland'],
];

// These shapes need surrounding map context to be distinguished reliably.
const ambiguousPairs = [['tea', 'historic-site'], ['town-hall', 'tree-field']];

export function shuffle(items, random = Math.random) {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index--) {
    const other = Math.floor(random() * (index + 1));
    [shuffled[index], shuffled[other]] = [shuffled[other], shuffled[index]];
  }
  return shuffled;
}

export function makeChoices(answer, pool, random = Math.random) {
  const excluded = new Set([answer.id]);
  for (const pair of ambiguousPairs) {
    if (pair.includes(answer.id)) pair.forEach(id => excluded.add(id));
  }
  const related = new Set(groups.filter(group => group.includes(answer.id)).flat());
  const candidates = shuffle(pool.filter(item => !excluded.has(item.id)), random);
  const similar = candidates.filter(item => related.has(item.id));
  const sameCategory = candidates.filter(item => !related.has(item.id) && item.category === answer.category);
  const others = candidates.filter(item => !related.has(item.id) && item.category !== answer.category);
  const preferred = [...similar.slice(0, 2), ...sameCategory, ...others, ...similar.slice(2)];
  if (preferred.length < 3) throw new Error('4択を作るための教材データが足りません。');
  return shuffle([answer, ...preferred.slice(0, 3)], random);
}

export function createRun({mode, level, pool, targets = pool, now = () => performance.now(), random = Math.random}) {
  return {
    mode, level, pool, targets, now, random, deck: [], question: null, response: null,
    attempts: 0, correct: 0, mistakes: new Map(),
    startedAt: mode === 'time' ? now() : null, finishedAt: null,
  };
}

export function nextQuestion(run) {
  if (run.finishedAt !== null) return null;
  if (!run.deck.length) {
    if (run.mode === 'practice' && run.attempts >= run.targets.length) return null;
    run.deck = shuffle(run.targets, run.random);
    if (run.deck.length > 1 && run.deck[0].id === run.question?.answer.id) {
      [run.deck[0], run.deck[1]] = [run.deck[1], run.deck[0]];
    }
  }
  const answer = run.deck.shift();
  run.question = {answer, choices: makeChoices(answer, run.pool, run.random)};
  run.response = null;
  return run.question;
}

export function submitAnswer(run, choiceId) {
  if (run.response || run.finishedAt !== null || !run.question) return null;
  const choice = run.question.choices.find(item => item.id === choiceId);
  if (!choice) return null;
  const {answer} = run.question;
  const correct = choiceId === answer.id;
  run.attempts++;
  if (correct) {
    run.correct++;
    if (run.mode === 'time' && run.correct === TARGET) run.finishedAt = run.now();
  } else if (run.mode === 'time') {
    const mistake = run.mistakes.get(answer.id) ?? {symbol: answer, count: 0, choices: new Set()};
    mistake.count++;
    mistake.choices.add(choice.name);
    run.mistakes.set(answer.id, mistake);
  }
  run.response = {correct, choice};
  return run.response;
}

export function elapsed(run) {
  return run.startedAt === null ? 0 : Math.max(0, (run.finishedAt ?? run.now()) - run.startedAt);
}

export function formatTime(milliseconds, japanese = false) {
  const total = Math.floor(milliseconds / 10);
  const minutes = Math.floor(total / 6000);
  const seconds = String(Math.floor(total / 100) % 60).padStart(2, '0');
  const fraction = String(total % 100).padStart(2, '0');
  return japanese ? minutes + '分' + seconds + '秒' + fraction :
    String(minutes).padStart(2, '0') + ':' + seconds + '.' + fraction;
}
