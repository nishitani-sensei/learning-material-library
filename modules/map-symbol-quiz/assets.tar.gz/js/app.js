import {categories, sources, symbols} from '../data/symbols.js';
import {createRun, elapsed, FEEDBACK_MS, formatTime, nextQuestion, submitAnswer, TARGET} from './quiz.js';
import {createRecords} from './storage.js';

const levels = {basic: '基本', all: '全56種類'};
const modeNames = {endless: 'エンドレスモード', time: 'タイムアタックモード', practice: 'まちがえた問題の練習'};
const icons = {
  loop: '<path d="M20 7v5h-5M4 17v-5h5M5.3 8.5a7.5 7.5 0 0 1 12.6-2.3L20 9M4 15l2.1 2.8a7.5 7.5 0 0 0 12.6-2.3"/>',
  time: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9v4l2.5 1.5M9 2h6m3.6 3.4 1.4-1.4"/>',
  book: '<path d="M12 6v14m0-14C8.5 3.7 6.2 4 3.5 4.8v13.7c3.2-.8 5.7-.3 8.5 1.5m0-14c3.5-2.3 5.8-2 8.5-1.2v13.7c-3.2-.8-5.7-.3-8.5 1.5"/>',
  trophy: '<path d="M8 4h8v6a4 4 0 0 1-8 0zm0 2H4v2a4 4 0 0 0 4 4m8-6h4v2a4 4 0 0 1-4 4m-4 2v5m-4 1h8"/>',
  find: '<circle cx="10.5" cy="10.5" r="5.5"/><path d="m15 15 4 4"/>',
};
const app = document.querySelector('#app');
const dialog = document.querySelector('#leave-dialog');
const records = createRecords();
const byId = new Map(symbols.map(symbol => [symbol.id, symbol]));
const basicPool = symbols.filter(symbol => symbol.isBasic);
const filters = {name: '', category: '', basic: false};
let level = 'basic';
let screen = 'home';
let run = null;
let result = null;
let detail = null;
let detailReturn = null;
let leaveDestination = null;
let advanceTimer = null;
let clockTimer = null;

function icon(name) {
  return `<svg class="icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name]}</svg>`;
}

function button(label, action, style = 'neutral', extras = '') {
  return `<button type="button" class="button ${style}" data-action="${action}" ${extras}>${label}</button>`;
}

function nameOf(symbol) {
  const names = symbol.name.split('・');
  const readings = symbol.reading.split('・');
  if (symbol.name.startsWith('その他の')) {
    return 'その他の<wbr>' + ruby(symbol.name.slice(4), symbol.reading.slice(4));
  }
  return names.map((name, index) => ruby(name, readings[index])).join('・<wbr>');
}

function ruby(name, reading) {
  return `<ruby>${name}<rp>（</rp><rt>${reading}</rt><rp>）</rp></ruby>`;
}

function picture(symbol, purpose = 'named') {
  const alt = purpose === 'question' ? '問題の地図記号' : '';
  return `<span class="picture"><img src="${symbol.imagePath}" alt="${alt}" width="100" height="100" draggable="false"></span>`;
}

function explanation(symbol, showSource = false) {
  return `<div class="explanation">
    <div><h3>どんな場所？</h3><p>${symbol.description}</p></div>
    ${symbol.origin ? `<div><h3>形のなりたち</h3><p>${symbol.origin}</p></div>` : ''}
    <div><h3>おぼえ方</h3><p>${symbol.memoryTip}</p></div>
    ${symbol.note ? `<p class="map-note">${symbol.note}</p>` : ''}
    ${showSource ? `<p class="source-links">資料 ${symbol.source.map(key => {
      const [label, url] = sources[key];
      return `<a href="${url}" rel="noopener noreferrer" target="_blank">${label}</a>`;
    }).join(' · ')}</p>` : ''}
  </div>`;
}

function levelLabel(selected) {
  return `<span class="level-label">${levels[selected]}</span>`;
}

function home() {
  const best = records.read(level);
  return `<div class="home-layout">
    <section class="hero">
      <div class="hero-shade"></div>
      <div class="hero-content">
        <h1 tabindex="-1">地図記号<br>クイズ</h1>
        <p><span>地図記号を楽しく</span><wbr><span>マスターしよう！</span></p>
      </div>
      <div class="map-marker marker-shrine" aria-hidden="true"><img src="./assets/symbols/shrine.svg" alt="" width="28" height="28"></div>
      <div class="map-marker marker-rice" aria-hidden="true"><img src="./assets/symbols/rice.svg" alt="" width="28" height="28"></div>
      <div class="map-marker marker-light" aria-hidden="true"><img src="./assets/symbols/lighthouse.svg" alt="" width="28" height="28"></div>
    </section>
    <section class="menu" aria-label="遊び方をえらぶ">
      <h2 id="choose-level"><ruby>出題<rt>しゅつだい</rt></ruby>レベル</h2>
      <div class="levels" role="group" aria-labelledby="choose-level">
        ${Object.entries(levels).map(([id, label]) => `<button type="button" class="level-choice" data-action="level" data-level="${id}" aria-pressed="${id === level}">
          <b>${label}</b><span>${id === 'basic' ? 'よく見る24種類' : 'すべての記号'}</span></button>`).join('')}
      </div>
      <div class="mode-buttons">
        ${modeButton('loop', 'endless', modeNames.endless, '時間を気にせず、じっくり学ぶ')}
        ${modeButton('time', 'time-setup', modeNames.time, '30問正解するまでの時間に挑戦')}
        ${modeButton('book', 'catalog', '地図記号一覧', '全56種類の記号を見くらべる')}
      </div>
      <div class="best-summary">
        <span class="trophy-icon">${icon('trophy')}</span>
        <span><b>${levels[level]}の最高記録</b><span>${best === null ? 'まだ記録がありません' : formatTime(best, true)}</span></span>
      </div>
    </section>
  </div>`;
}

function modeButton(mark, action, title, description) {
  return `<button type="button" class="mode-button mode-${mark}" data-action="${action}">
    <span class="mode-icon">${icon(mark)}</span><span class="mode-copy"><b>${title}</b><span>${description}</span></span>
  </button>`;
}

function timeSetup() {
  return `<section class="panel intro-panel">
    ${levelLabel(level)}
    <span class="intro-icon">${icon('time')}</span>
    <h1 tabindex="-1">タイムアタック</h1>
    <p><strong>30問正解</strong>するまでの時間をはかるよ。<br>まちがえても、つぎの問題に進みます。</p>
    <div class="actions">
      ${button('スタート！', 'time-start', 'primary')}
      ${button('トップにもどる', 'home')}
    </div>
  </section>`;
}

function question() {
  const timed = run.mode === 'time';
  const practice = run.mode === 'practice';
  const symbol = run.question.answer;
  const context = {'town-hall': '建物のしるし', 'tree-field': '土地のようすを表すしるし'}[symbol.id];
  return `<section class="play-layout">
    <div class="play-top">
      <div class="play-mode"><span>${modeNames[run.mode]}</span>${levelLabel(run.level)}</div>
      ${button('おわる', 'leave', 'quiet small')}
    </div>
    <div class="scoreboard" ${timed ? '' : 'aria-live="polite"'}>
      <div>
        <span class="score-caption">${timed ? '正解' : practice ? '練習' : ''}</span>
        <b id="score-count">${score()}</b>
        <span id="score-attempts" class="attempts">${!timed && !practice ? run.attempts + '問にチャレンジ' : ''}</span>
      </div>
      ${timed ? `<div class="timer"><span>タイム</span> <b id="timer">${formatTime(elapsed(run))}</b></div>` : ''}
    </div>
    <div class="question-body">
      <div class="question-figure">
        <h1 tabindex="-1">この地図記号は<br class="mobile-break">何を表しているかな？</h1>
        ${picture(symbol, 'question')}
        ${context ? `<p class="figure-context">${context}</p>` : ''}
      </div>
      <div class="question-controls">
        <div class="choices" aria-label="答えをえらぶ">
          ${run.question.choices.map((item, index) => `<button type="button" class="choice" data-action="answer" data-id="${item.id}">
            <span class="choice-letter" aria-hidden="true">${index + 1}</span><span class="choice-name">${nameOf(item)}</span><span class="choice-mark" aria-hidden="true"></span>
          </button>`).join('')}
        </div>
        <div id="feedback" class="feedback" aria-live="polite" aria-atomic="true"></div>
      </div>
    </div>
    <div id="answer-explanation"></div>
  </section>`;
}

function score() {
  if (run.mode === 'time') return run.correct + ' / ' + TARGET;
  if (run.mode === 'practice') return Math.min(run.response ? run.attempts : run.attempts + 1, run.targets.length) + ' / ' + run.targets.length;
  return '今現在、' + run.correct + '問正解中！';
}

function showFeedback(response) {
  const {answer} = run.question;
  for (const choice of app.querySelectorAll('.choice')) {
    choice.setAttribute('aria-disabled', 'true');
    const mark = choice.querySelector('.choice-mark');
    if (choice.dataset.id === answer.id) {
      choice.classList.add('choice-correct');
      mark.textContent = '✓';
    } else if (choice.dataset.id === response.choice.id) {
      choice.classList.add('choice-wrong');
      mark.textContent = '×';
    }
  }
  app.querySelector('#score-count').textContent = score();
  if (run.mode === 'endless') app.querySelector('#score-attempts').textContent = run.attempts + '問にチャレンジ';

  const feedback = app.querySelector('#feedback');
  feedback.classList.add(response.correct ? 'positive' : 'negative');
  feedback.innerHTML = `<b>${response.correct ? '✓ せいかい！' : '× ざんねん！'}</b>
    ${!response.correct && run.mode === 'time' ? `<span>答えは ${answer.name}</span>` : ''}`;
  if (run.mode === 'time') return;

  const lastPractice = run.mode === 'practice' && run.attempts === run.targets.length;
  app.querySelector('#answer-explanation').innerHTML = `<section class="panel answer-panel">
    <div class="answer-heading"><span class="answer-caption">正しい答え</span><h2>${nameOf(answer)}</h2></div>
    ${explanation(answer)}
    <div class="actions">${button(lastPractice ? '練習の結果を見る' : 'つぎの問題へ', 'next', 'primary')}</div>
  </section>`;
  const panel = app.querySelector('.answer-panel');
  if (panel.getBoundingClientRect().top > window.innerHeight - 105) {
    panel.scrollIntoView({block: 'start', behavior: 'auto'});
  }
}

function stat(label, value) {
  return `<div class="stat"><dt>${label}</dt><dd>${value}</dd></div>`;
}

function results() {
  if (result.mode === 'time') {
    return `<section class="panel result-panel">
      ${levelLabel(result.level)}
      <span class="intro-icon">${icon('trophy')}</span>
      <h1 tabindex="-1">${result.record.improved ? '記録更新おめでとう！' : '30問クリア！おめでとう！'}</h1>
      ${result.record.improved ? '<p>30問クリア！</p>' : ''}
      <div class="result-time"><span>今回のタイム</span><strong>${formatTime(result.time)}</strong></div>
      <dl class="stats">
        ${stat('最高記録', formatTime(result.record.best))}${stat('正解', TARGET + '問')}
        ${stat('不正解', (result.attempts - result.correct) + '問')}${stat('挑戦した総問題数', result.attempts + '問')}
      </dl>
      ${result.record.saved ? '' : '<p class="map-note">このブラウザでは、ページを閉じると最高記録が消えます。</p>'}
      <div class="actions result-actions">
        ${button('まちがえた問題を復習', 'review', 'primary')}
        ${button('もう一度チャレンジ', 'retry')}
        ${button('トップにもどる', 'home')}
      </div>
    </section>`;
  }
  const practice = result.mode === 'practice';
  const rate = result.attempts === 0 ? '―' : Math.round(result.correct / result.attempts * 100) + '%';
  return `<section class="panel result-panel">
    ${levelLabel(result.level)}
    <span class="intro-icon">${icon('trophy')}</span>
    <h1 tabindex="-1">${practice ? '練習おつかれさま！' : 'チャレンジの結果'}</h1>
    <dl class="stats">
      ${stat('挑戦した問題数', result.attempts + '問')}${stat('正解', result.correct + '問')}${stat('正答率', rate)}
    </dl>
    <div class="actions result-actions">
      ${button(practice ? '復習にもどる' : 'もう一度', practice ? 'review' : 'retry', 'primary')}
      ${button('トップにもどる', 'home')}
    </div>
  </section>`;
}

let lastTimeResult = null;

function review() {
  const mistakes = [...lastTimeResult.mistakes.values()];
  return `<section class="content-layout">
    <div class="section-heading">
      <div>${levelLabel(lastTimeResult.level)}<h1 tabindex="-1">まちがえた問題を復習</h1></div>
      ${button('結果にもどる', 'time-result')}
    </div>
    ${mistakes.length ? `<p class="review-start">${button('まちがえた問題だけ練習する', 'practice', 'primary')}</p>
      <div class="review-grid">${mistakes.map(({symbol, count, choices}) => `<article class="panel review-card">
        <div class="review-card-top">${picture(symbol)}<div><h2>${nameOf(symbol)}</h2><p>まちがえた回数 ${count}回</p></div></div>
        <p class="selected-answers">えらんだ答え ${[...choices].join('、')}</p>
        ${explanation(symbol)}
      </article>`).join('')}</div>` :
      '<div class="panel clear-panel"><h2>全問ノーミス！すばらしい！</h2></div>'}
  </section>`;
}

function catalog() {
  return `<section class="content-layout">
    <div class="section-heading"><div><h1 tabindex="-1">地図記号一覧</h1><p>記号を押すと、意味やおぼえ方が見られます。</p></div>
      ${button('トップにもどる', 'home')}
    </div>
    <div class="catalog-filters">
      <label class="search-label" for="catalog-name"><span>記号の名前</span><span class="search-input">${icon('find')}
        <input type="search" id="catalog-name" placeholder="例　こうばん" autocomplete="off"></span></label>
      <label for="catalog-category"><span>カテゴリー</span>
        <select id="catalog-category"><option value="">すべて</option>${categories.map(category => `<option value="${category}">${category}</option>`).join('')}</select>
      </label>
      <label class="basic-filter"><input type="checkbox" id="catalog-basic"><span>基本だけ表示</span></label>
    </div>
    <p class="catalog-count" aria-live="polite"></p>
    <div class="catalog-grid"></div>
  </section>`;
}

function normalizeSearch(value) {
  return value.normalize('NFKC').toLowerCase().replace(/[ァ-ヶ]/g, character => String.fromCharCode(character.charCodeAt(0) - 96))
    .replace(/[\s・･／/（）()]/g, '');
}

function updateCatalog() {
  const search = normalizeSearch(filters.name);
  const matches = symbols.filter(symbol =>
    (!filters.category || symbol.category === filters.category) && (!filters.basic || symbol.isBasic) &&
    [symbol.name, symbol.reading, ...symbol.aliases].some(value => normalizeSearch(value).includes(search)));
  app.querySelector('.catalog-count').textContent = matches.length + '種類';
  app.querySelector('.catalog-grid').innerHTML = matches.length ?
    matches.map(symbol => `<button class="catalog-card" type="button" data-action="detail" data-id="${symbol.id}">
      ${picture(symbol)}<b>${nameOf(symbol)}</b>${symbol.isBasic ? '<span class="catalog-basic-tag">基本</span>' : ''}
    </button>`).join('') :
    '<p class="empty-message">見つかりませんでした。別の名前でさがしてみよう。</p>';
}

function details() {
  return `<section class="content-layout">
    <div class="section-heading">${button('一覧にもどる', 'catalog-back')}</div>
    <article class="panel detail-panel">
      <div class="detail-art">${picture(detail)}</div>
      <div>
        <p class="detail-category">${detail.category}${detail.isBasic ? ' ・ 基本' : ''}</p>
        <h1 tabindex="-1">${nameOf(detail)}</h1>
        ${explanation(detail, true)}
      </div>
    </article>
  </section>`;
}

function bibliography() {
  return `<section class="panel intro-panel source-panel">
    <h1 tabindex="-1">教材の出典</h1>
    <p>出題範囲は、ちびむすドリルの「地図記号テスト」2ページです。図柄と解説は、国土地理院の地形図の資料と照らし合わせて作成しました。</p>
    <ul>${[sources.current, sources.standard, sources.history, sources.compare].map(([label, url]) =>
      `<li><a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a></li>`).join('')}</ul>
    ${button('トップにもどる', 'home')}
  </section>`;
}

const views = {home, 'time-setup': timeSetup, question, result: results, catalog, detail: details, review, sources: bibliography};

function navigate(next, focus = true) {
  screen = next;
  app.innerHTML = views[screen]();
  document.body.dataset.screen = screen;
  if (screen === 'catalog') {
    app.querySelector('#catalog-name').value = filters.name;
    app.querySelector('#catalog-category').value = filters.category;
    app.querySelector('#catalog-basic').checked = filters.basic;
    updateCatalog();
  }
  if (focus) {
    window.scrollTo(0, 0);
    app.querySelector('h1')?.focus({preventScroll: true});
  }
}

function updateClock() {
  const timer = app.querySelector('#timer');
  if (timer && run?.mode === 'time') timer.textContent = formatTime(elapsed(run));
}

function stopTimers() {
  window.clearTimeout(advanceTimer);
  window.clearInterval(clockTimer);
  advanceTimer = null;
  clockTimer = null;
}

function start(mode, selected = level) {
  stopTimers();
  const pool = selected === 'basic' ? basicPool : symbols;
  const targets = mode === 'practice' ? [...lastTimeResult.mistakes.values()].map(mistake => mistake.symbol) : pool;
  run = createRun({mode, level: selected, pool, targets});
  nextQuestion(run);
  navigate('question');
  if (mode === 'time') clockTimer = window.setInterval(updateClock, 43);
}

function celebrate() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const confetti = document.createElement('div');
  confetti.className = 'celebration';
  confetti.setAttribute('aria-hidden', 'true');
  for (let side = 0; side < 2; side++) {
    const burst = document.createElement('div');
    burst.className = side ? 'burst burst-right' : 'burst';
    for (let index = 0; index < 18; index++) {
      const piece = document.createElement('i');
      const direction = side ? -1 : 1;
      piece.style.setProperty('--dx', direction * (5 + Math.random() * 30) + 'vw');
      piece.style.setProperty('--peak', -(90 + Math.random() * 210) + 'px');
      piece.style.setProperty('--turn', (Math.random() * 720 - 360) + 'deg');
      piece.style.setProperty('--color', ['#f6af3c', '#308f6d', '#f36d55', '#7da7de'][index % 4]);
      piece.style.animationDelay = index * 12 + 'ms';
      burst.append(piece);
    }
    confetti.append(burst);
  }
  app.append(confetti);
  window.setTimeout(() => confetti.remove(), 3100);
}

function finish() {
  stopTimers();
  result = run;
  run = null;
  if (result.mode === 'time') {
    result.time = elapsed(result);
    result.record = records.save(result.level, result.time);
    lastTimeResult = result;
  }
  navigate('result');
  if (result.record?.improved) celebrate();
}

function advance() {
  if (!nextQuestion(run)) finish();
  else navigate('question');
}

function answer(id) {
  if (app.querySelector('.question-figure .picture-error')) return;
  const response = submitAnswer(run, id);
  if (!response) return;
  if (run.finishedAt !== null) {
    finish();
    return;
  }
  showFeedback(response);
  if (run.mode === 'time') advanceTimer = window.setTimeout(advance, FEEDBACK_MS);
}

function leave(destination) {
  if (screen !== 'question') {
    navigate(destination);
    return;
  }
  leaveDestination = destination;
  dialog.querySelector('#leave-message').textContent = run.mode === 'time' ?
    '途中でおわると、今回のタイムは最高記録に入りません。' : 'ここまで解いた問題で、今回の結果を表示します。';
  dialog.returnValue = '';
  if (!dialog.open) dialog.showModal();
}

dialog.addEventListener('close', () => {
  if (dialog.returnValue !== 'finish' || screen !== 'question') return;
  if (run.mode === 'time') {
    stopTimers();
    run = null;
    navigate(leaveDestination);
  } else {
    finish();
  }
});

document.addEventListener('click', event => {
  const control = event.target.closest('button[data-action]');
  if (!control) return;
  switch (control.dataset.action) {
    case 'home': leave('home'); break;
    case 'sources': leave('sources'); break;
    case 'level':
      level = control.dataset.level;
      navigate('home', false);
      app.querySelector('[data-level="' + level + '"]').focus({preventScroll: true});
      break;
    case 'endless': start('endless'); break;
    case 'time-setup': navigate('time-setup'); break;
    case 'time-start': start('time'); break;
    case 'leave': leave('home'); break;
    case 'answer': if (screen === 'question') answer(control.dataset.id); break;
    case 'next': if (screen === 'question' && run.response) advance(); break;
    case 'retry':
      level = result.level;
      if (result.mode === 'time') navigate('time-setup');
      else start('endless');
      break;
    case 'review': navigate('review'); break;
    case 'practice': start('practice', lastTimeResult.level); break;
    case 'time-result': result = lastTimeResult; navigate('result'); break;
    case 'catalog':
      Object.assign(filters, {name: '', category: '', basic: false});
      navigate('catalog');
      break;
    case 'detail':
      detail = byId.get(control.dataset.id);
      detailReturn = {id: detail.id, scroll: window.scrollY};
      navigate('detail');
      break;
    case 'catalog-back':
      navigate('catalog', false);
      app.querySelector('[data-id="' + detailReturn.id + '"]')?.focus({preventScroll: true});
      window.scrollTo(0, detailReturn.scroll);
      break;
    case 'restore-picture': {
      const slot = app.querySelector('.question-figure .picture');
      slot.outerHTML = picture(run.question.answer, 'question');
      break;
    }
  }
});

app.addEventListener('input', event => {
  if (event.target.id !== 'catalog-name') return;
  filters.name = event.target.value;
  updateCatalog();
});

app.addEventListener('change', event => {
  if (event.target.id === 'catalog-category') filters.category = event.target.value;
  else if (event.target.id === 'catalog-basic') filters.basic = event.target.checked;
  else return;
  updateCatalog();
});

app.addEventListener('error', event => {
  const slot = event.target.closest?.('.picture');
  if (!slot) return;
  slot.classList.add('picture-error');
  slot.innerHTML = '<span>記号の画像を表示できませんでした</span>';
  if (slot.closest('.question-figure')) {
    slot.setAttribute('role', 'alert');
    slot.insertAdjacentHTML('beforeend', button('もう一度表示', 'restore-picture', 'quiet small'));
  }
}, true);

document.addEventListener('visibilitychange', updateClock);
window.addEventListener('pageshow', updateClock);
navigate('home', false);
