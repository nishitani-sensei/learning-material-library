const prefix = 'map-symbol-quiz:v1:best:';

export function createRecords(getStorage = () => window.localStorage) {
  const sessionBest = new Map();

  function read(level) {
    const inMemory = sessionBest.get(level) ?? null;
    try {
      const raw = getStorage().getItem(prefix + level);
      const saved = Number(raw);
      if (raw === null || !Number.isFinite(saved) || saved < 0) return inMemory;
      return inMemory === null ? saved : Math.min(saved, inMemory);
    } catch {
      return inMemory;
    }
  }

  return {
    read,
    save(level, milliseconds) {
      const previous = read(level);
      if (previous !== null && milliseconds >= previous) {
        return {best: previous, improved: false, saved: !sessionBest.has(level)};
      }
      try {
        getStorage().setItem(prefix + level, String(milliseconds));
        sessionBest.delete(level);
        return {best: milliseconds, improved: true, saved: true};
      } catch {
        sessionBest.set(level, milliseconds);
        return {best: milliseconds, improved: true, saved: false};
      }
    },
  };
}
