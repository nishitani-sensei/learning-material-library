import { AREA, BOX_MIN, LIMIT, FORMAT, NOTE, backupObject, checkLimits, duplicateWork, ordered } from './model.js';

const object = value => value && typeof value === 'object' && !Array.isArray(value);
const number = (value, min, max) => Number.isFinite(value) && min <= value && value <= max;
const integer = (value, min, max) => Number.isInteger(value) && number(value, min, max);
const date = value => typeof value === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value) &&
  Number.isFinite(Date.parse(value));
const text = (value, max, required = false) => typeof value === 'string' &&
  Array.from(value).length <= max && (!required || Boolean(value.trim()));
const color = value => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
const id = value => typeof value === 'string' && /^[a-z0-9_-]{1,80}$/i.test(value);

function requireValue(condition, message = 'JSONの記録の形式が正しくありません。') {
  if (!condition) throw new Error(message);
}

function unique(value, ids) {
  requireValue(id(value) && !ids.has(value), 'JSONに重複した番号や無効な番号があります。');
  ids.add(value);
  return value;
}

function inspectBox(element) {
  const { x, y, width, height } = element;
  requireValue(number(x, AREA.left, AREA.right) && number(y, AREA.top, AREA.bottom) &&
    number(width, BOX_MIN.width, AREA.right - x + 1e-7) &&
    number(height, BOX_MIN.height, AREA.bottom - y + 1e-7));
  return { x, y, width, height };
}

function inspectElement(element, ids) {
  requireValue(object(element));
  const base = { id: unique(element.id, ids), type: element.type };
  switch (element.type) {
    case 'person':
      requireValue(text(element.name, 50, true) && color(element.fillColor) && color(element.borderColor));
      return { ...base, ...inspectBox(element), name: element.name, fillColor: element.fillColor, borderColor: element.borderColor };
    case 'relation': {
      const { sourceId, targetId, label, lineStyle, arrowMode, color: ink, labelOffset } = element;
      requireValue(id(sourceId) && id(targetId) && sourceId !== targetId);
      requireValue(text(label, 60) && (lineStyle === 'solid' && ['none', 'end', 'both'].includes(arrowMode) ||
        lineStyle === 'dashed' && arrowMode === 'none') && color(ink));
      requireValue(object(labelOffset) && number(labelOffset.x, -1485, 1485) && number(labelOffset.y, -1050, 1050));
      return { ...base, sourceId, targetId, label, lineStyle, arrowMode, color: ink,
        labelOffset: { x: labelOffset.x, y: labelOffset.y } };
    }
    case 'note':
      requireValue(Object.hasOwn(NOTE, element.noteType) && text(element.text, 1000, true) && color(element.fillColor));
      return { ...base, ...inspectBox(element), noteType: element.noteType, text: element.text, fillColor: element.fillColor };
    case 'text':
      requireValue(text(element.text, 1000, true) && color(element.color) && number(element.fontSize, 18, 64));
      return { ...base, ...inspectBox(element), text: element.text, fontSize: element.fontSize, color: element.color };
    case 'stroke':
      requireValue(Array.isArray(element.points) && element.points.length > 0 && element.points.length <= LIMIT.points &&
        color(element.color) && number(element.strokeWidth, 1, 30));
      return { ...base, color: element.color, strokeWidth: element.strokeWidth, points: element.points.map(point => {
        requireValue(object(point) && number(point.x, AREA.left, AREA.right) && number(point.y, AREA.top, AREA.bottom));
        const result = { x: point.x, y: point.y };
        if ('pressure' in point) {
          requireValue(number(point.pressure, 0, 1));
          result.pressure = point.pressure;
        }
        return result;
      }) };
    default:
      throw new Error('JSONに対応していない編集項目があります。');
  }
}

export function decodeBackup(source) {
  let data;
  try { data = JSON.parse(source); }
  catch { throw new Error('JSONを読み取れませんでした。書き出したファイルを選んでください。'); }
  requireValue(object(data) && data.format === FORMAT, '人物相関図のバックアップを選んでください。');
  requireValue(data.version === 1, 'このバックアップは、対応していない版で作られています。');
  const { work, scenes } = data;
  requireValue(date(data.exportedAt) && object(work) && id(work.id) && text(work.title, 50, true) &&
    date(work.createdAt) && date(work.updatedAt) && integer(work.revision, 0, Number.MAX_SAFE_INTEGER - 1));
  requireValue(Array.isArray(scenes) && scenes.length > 0 && scenes.length <= LIMIT.scenes,
    '場面の数が1〜' + LIMIT.scenes + 'の範囲を超えています。');
  const ids = new Set([work.id]);
  const orders = new Set();
  const checked = scenes.map(scene => {
    requireValue(object(scene));
    const { workId, name, order, createdAt, updatedAt, elements } = scene;
    requireValue(workId === work.id && text(name, 30, true) && date(createdAt) && date(updatedAt) &&
      integer(order, 0, scenes.length - 1) && !orders.has(order));
    requireValue(Array.isArray(elements) && elements.length <= LIMIT.elements,
      '1場面に入れられる編集項目の数を超えています。');
    orders.add(order);
    let count = 0;
    for (const element of elements) {
      if (element?.type === 'stroke' && Array.isArray(element.points)) count += element.points.length;
    }
    requireValue(count <= LIMIT.points, '1場面で保存できる手書きの量を超えています。');
    const sceneId = unique(scene.id, ids);
    const copied = elements.map(element => inspectElement(element, ids));
    const people = new Set(copied.filter(element => element.type === 'person').map(element => element.id));
    requireValue(copied.every(element => element.type !== 'relation' ||
      people.has(element.sourceId) && people.has(element.targetId)), 'JSONに、相手が見つからない関係線があります。');
    return { id: sceneId, workId, name: name.trim(), order, createdAt, updatedAt, elements: copied };
  });
  const cleanWork = { id: work.id, title: work.title.trim(), createdAt: work.createdAt,
    updatedAt: work.updatedAt, revision: work.revision };
  const result = duplicateWork({ work: cleanWork, scenes: ordered(checked) }, cleanWork.title, true);
  checkLimits(result.work, result.scenes);
  return result;
}

export async function readBackup(file) {
  requireValue(file.size <= LIMIT.bytes, '20 MiBを超えるJSONは読み込めません。');
  return decodeBackup(await file.text());
}

export function jsonFile(work, scenes) {
  return new Blob([JSON.stringify(backupObject(work, scenes))], { type: 'application/json' });
}
