import { now, ordered } from './model.js';

export const DB_NAME = 'characterRelationshipApp';
export class ConflictError extends Error {
  constructor() {
    super('別のタブでこの作品が更新されました。必要なら今の編集をJSONに保存し、保存済みの作品を開き直してください。');
    this.name = 'ConflictError';
  }
}

function requestResult(request, next = value => value) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => {
      try { resolve(next(request.result)); }
      catch (error) { reject(error); }
    };
    request.onerror = () => reject(request.error);
  });
}

export function openStore(factory = indexedDB, name = DB_NAME) {
  return new Promise((resolve, reject) => {
    const request = factory.open(name, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      db.createObjectStore('works', { keyPath: 'id' });
      const scenes = db.createObjectStore('scenes', { keyPath: 'id' });
      scenes.createIndex('workId', 'workId');
      scenes.createIndex('order', ['workId', 'order']);
      db.createObjectStore('settings', { keyPath: 'key' });
    };
    request.onerror = () => reject(request.error);
    request.onblocked = () => {
      request.onsuccess = () => request.result.close();
      reject(new Error('ほかのタブを閉じてから、このページを開き直してください。'));
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      resolve(makeStore(db));
    };
  });
}

function makeStore(db) {
  async function transaction(tables, mode, perform) {
    const tx = db.transaction(tables, mode);
    const done = new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onabort = () => reject(tx.error ?? new Error('保存が中断されました。'));
    });
    let result;
    try {
      // Start all requests inside the transaction or from request continuations.
      result = await perform(...tables.map(table => tx.objectStore(table)));
    } catch (error) {
      try { tx.abort(); } catch { /* It may already have aborted. */ }
      await done.catch(() => {});
      throw error;
    }
    await done;
    return result;
  }

  return {
    close: () => db.close(),
    async list() {
      return transaction(['works', 'scenes'], 'readonly', (works, scenes) => requestResult(works.getAll(), async entries => {
        const counts = await Promise.all(entries.map(work => requestResult(scenes.index('workId').count(work.id))));
        return entries.map((work, i) => ({ ...work, count: counts[i] }))
          .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt) || a.id.localeCompare(b.id));
      }));
    },
    async read(id) {
      return transaction(['works', 'scenes'], 'readonly', async (works, scenes) => {
        const [work, all] = await Promise.all([
          requestResult(works.get(id)), requestResult(scenes.index('workId').getAll(id)),
        ]);
        return work ? { work, scenes: ordered(all) } : null;
      });
    },
    async add(work, list) {
      return transaction(['works', 'scenes'], 'readwrite', (works, scenes) => {
        const writes = [works.add(work), ...list.map(scene => scenes.add(scene))];
        return Promise.all(writes.map(request => requestResult(request)));
      });
    },
    async change(work, { put = [], remove = [], title = work.title, deleteWork = false } = {}) {
      return transaction(['works', 'scenes'], 'readwrite', (works, scenes) => requestResult(works.get(work.id), async current => {
        if (!current || current.revision !== work.revision) throw new ConflictError();
        const updated = { ...current, title, updatedAt: now(), revision: current.revision + 1 };
        const writes = [
          deleteWork ? works.delete(work.id) : works.put(updated),
          ...put.map(scene => scenes.put(scene)),
          ...remove.map(id => scenes.delete(id)),
        ];
        await Promise.all(writes.map(request => requestResult(request)));
        return updated;
      }));
    },
    async getSetting(key) {
      const entry = await transaction(['settings'], 'readonly', settings => requestResult(settings.get(key)));
      return entry?.value;
    },
    async setSetting(key, value) {
      return transaction(['settings'], 'readwrite', settings => requestResult(settings.put({ key, value })));
    },
  };
}
