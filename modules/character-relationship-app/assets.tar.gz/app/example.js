export const example = {
  title: '森の小さな手紙',
  name: '手紙を見つけた場面',
  elements: [
    { id: 'fox', type: 'person', name: 'こぎつね', x: 196, y: 267, width: 274, height: 117, fillColor: '#DCEDE1', borderColor: '#68937B' },
    { id: 'rabbit', type: 'person', name: 'うさぎ', x: 1002, y: 271, width: 275, height: 110, fillColor: '#E7E0F8', borderColor: '#9C87B2' },
    { id: 'owl', type: 'person', name: 'ふくろう', x: 608, y: 749, width: 267, height: 111, fillColor: '#D9EEFA', borderColor: '#719CBA' },
    { id: 'line1', type: 'relation', sourceId: 'fox', targetId: 'rabbit', label: 'いっしょに考える', color: '#246849', lineStyle: 'solid', arrowMode: 'both', labelOffset: { x: 0, y: -6 } },
    { id: 'line2', type: 'relation', sourceId: 'rabbit', targetId: 'owl', label: 'たずねる', color: '#264D84', lineStyle: 'solid', arrowMode: 'end', labelOffset: { x: 0, y: 15 } },
    { id: 'line3', type: 'relation', sourceId: 'fox', targetId: 'owl', label: '', color: '#8353B0', lineStyle: 'dashed', arrowMode: 'none', labelOffset: { x: 0, y: 0 } },
    { id: 'note1', type: 'note', noteType: 'feeling', text: 'だれの手紙かな。\n届けてあげたい。', x: 100, y: 476, width: 337, height: 174, fillColor: '#FADBE7' },
    { id: 'note2', type: 'note', noteType: 'reason', text: '手紙に小さな\n羽が入っていたから。', x: 1030, y: 662, width: 360, height: 177, fillColor: '#F9EDB9' },
    { id: 'note3', type: 'note', noteType: 'event', text: '道で手紙を\nひろった。', x: 560, y: 420, width: 279, height: 173, fillColor: '#D9EEFA' },
  ],
};
