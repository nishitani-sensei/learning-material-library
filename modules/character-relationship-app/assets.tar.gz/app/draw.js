import { AREA, PAGE, NOTE, clamp, isBox } from './model.js';
import { contains, nearCurve, nearStroke, relationGeometry } from './geometry.js';

const FONT = '"Hiragino Sans", "Yu Gothic", "Meiryo", sans-serif';
const INK = '#263630';
const GREEN = '#246849';
const WIDTH = AREA.right - AREA.left;
const textLayouts = new WeakMap();

function font(ctx, size, weight = 500) {
  ctx.font = weight + ' ' + size + 'px ' + FONT;
}

function boxPath(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function wrapped(ctx, text, width) {
  const lines = [];
  for (const paragraph of text.split(/\r?\n/)) {
    let line = '';
    for (const character of paragraph) {
      if (line && ctx.measureText(line + character).width > width) {
        lines.push(line);
        line = '';
      }
      line += character;
    }
    lines.push(line);
  }
  return lines;
}

function preferredSize(item) {
  return item.type === 'person' ? 36 : item.type === 'note' ? 28 : item.fontSize;
}

function flow(ctx, item, size) {
  const person = item.type === 'person';
  const note = item.type === 'note';
  const scale = size / preferredSize(item);
  const step = size * 1.4;
  const padding = Math.max(6, (person ? 15 : note ? 19 : 10) * scale);
  const heading = note ? 36 * scale : 0;
  const lineWidth = item.width - padding * 2;
  font(ctx, size, person ? 700 : 500);
  const lines = wrapped(ctx, person ? item.name : item.text, lineWidth);
  return { size, padding, heading, step, lines, lineWidth, height: padding * 2 + heading + lines.length * step };
}

export function naturalBoxTextHeight(ctx, item) {
  ctx.save();
  const height = flow(ctx, item, preferredSize(item)).height;
  ctx.restore();
  return height;
}

export function boxTextLayout(ctx, item) {
  const cached = textLayouts.get(item);
  if (cached) return cached;
  ctx.save();
  const preferred = preferredSize(item);
  let layout = flow(ctx, item, preferred);
  if (layout.height > item.height) {
    let tooLarge = preferred;
    // At this size all 1,000 allowed characters fit in the minimum box,
    // even when nearly all of them are explicit line breaks.
    layout = flow(ctx, item, 0.025);
    for (let i = 0; i < 10; i++) {
      const size = (layout.size + tooLarge) / 2;
      const candidate = flow(ctx, item, size);
      if (candidate.height <= item.height) layout = candidate;
      else tooLarge = size;
    }
  }
  ctx.restore();
  textLayouts.set(item, layout);
  return layout;
}

function writeBox(ctx, item) {
  const { x, y, width, height } = item;
  const person = item.type === 'person';
  const note = item.type === 'note';
  if (person || note) {
    boxPath(ctx, x, y, width, height, person ? 24 : 15);
    ctx.fillStyle = item.fillColor;
    ctx.fill();
    ctx.lineWidth = person ? 2.8 : 2;
    ctx.strokeStyle = person ? item.borderColor : '#6A6F774C';
    ctx.stroke();
  }
  ctx.save();
  ctx.beginPath();
  ctx.rect(x + 2, y + 2, width - 4, height - 4);
  ctx.clip();
  const { size, padding, heading, step, lines, lineWidth } = boxTextLayout(ctx, item);
  ctx.textBaseline = 'middle';
  if (note) {
    font(ctx, 21 * size / preferredSize(item), 700);
    ctx.fillStyle = NOTE[item.noteType].ink;
    ctx.textAlign = 'left';
    ctx.fillText(NOTE[item.noteType].label, x + padding, y + padding + heading * 13 / 36, lineWidth);
  }
  font(ctx, size, person ? 700 : 500);
  ctx.textAlign = person ? 'center' : 'left';
  ctx.fillStyle = item.color ?? INK;
  const top = person ? Math.max(padding, (height - lines.length * step) / 2) : padding + heading;
  lines.forEach((line, i) => ctx.fillText(line, person ? x + width / 2 : x + padding, y + top + (i + 0.5) * step, lineWidth));
  ctx.restore();
}

export function labelBounds(ctx, item, path) {
  font(ctx, 25, 600);
  const lines = wrapped(ctx, item.label || '線', 290);
  const width = Math.max(54, ...lines.map(line => ctx.measureText(line).width + 28));
  const height = 12 + 33 * lines.length;
  return { x: clamp(path.base.x + item.labelOffset.x - width / 2, AREA.left + 3, AREA.right - width - 3),
    y: clamp(path.base.y + item.labelOffset.y - height / 2, AREA.top + 3, AREA.bottom - height - 3),
    width, height, lines };
}

function arrow(ctx, tip, toward, color) {
  const angle = Math.atan2(tip.y - toward.y, tip.x - toward.x);
  ctx.beginPath();
  ctx.moveTo(tip.x, tip.y);
  ctx.lineTo(tip.x - 22 * Math.cos(angle - 0.48), tip.y - 22 * Math.sin(angle - 0.48));
  ctx.lineTo(tip.x - 22 * Math.cos(angle + 0.48), tip.y - 22 * Math.sin(angle + 0.48));
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

function line(ctx, item, path, selected) {
  const { start, end, bend } = path;
  if (selected) {
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.quadraticCurveTo(bend.x, bend.y, end.x, end.y);
    ctx.strokeStyle = '#8DD4BF';
    ctx.lineWidth = 13;
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(start.x, start.y);
  ctx.quadraticCurveTo(bend.x, bend.y, end.x, end.y);
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.strokeStyle = item.color;
  ctx.setLineDash(item.lineStyle === 'dashed' ? [11, 10] : []);
  ctx.stroke();
  ctx.setLineDash([]);
  if (item.arrowMode !== 'none') arrow(ctx, end, bend, item.color);
  if (item.arrowMode === 'both') arrow(ctx, start, bend, item.color);
}

function lineLabel(ctx, item, path, selected) {
  const { x, y, width, height, lines } = labelBounds(ctx, item, path);
  boxPath(ctx, x, y, width, height, 12);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();
  ctx.lineWidth = selected ? 3 : 1.6;
  ctx.strokeStyle = selected ? GREEN : '#BAC7C0';
  ctx.stroke();
  ctx.fillStyle = item.color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  lines.forEach((text, i) => ctx.fillText(text, x + width / 2, y + 6 + (i + 0.5) * 33));
}

function stroke(ctx, item, selected) {
  const { points } = item;
  const start = points[0];
  if (!start) return;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(start.x, start.y);
  for (const point of points) ctx.lineTo(point.x, point.y);
  if (points.length === 1) ctx.lineTo(start.x + 0.02, start.y);
  if (selected) {
    ctx.strokeStyle = '#93D6C2';
    ctx.lineWidth = item.strokeWidth + 8;
    ctx.stroke();
  }
  ctx.strokeStyle = item.color;
  ctx.lineWidth = item.strokeWidth;
  ctx.stroke();
}

function header(ctx, title, name) {
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  font(ctx, 42, 750);
  ctx.fillStyle = INK;
  ctx.fillText(title, AREA.left, 57, WIDTH);
  font(ctx, 26, 600);
  ctx.fillStyle = GREEN;
  ctx.fillText(name, AREA.left, 104, WIDTH);
  ctx.fillStyle = '#CCDAD1';
  ctx.fillRect(AREA.left, 122, WIDTH, 2);
}

export function drawPaper(ctx, title, name, elements, { editing = false, selected = '', start = '', previewStroke } = {}) {
  ctx.save();
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, PAGE.width, PAGE.height);
  header(ctx, title, name);
  if (editing) {
    ctx.strokeStyle = '#A9BDB5';
    ctx.lineWidth = 1.4;
    ctx.setLineDash([5, 7]);
    ctx.strokeRect(AREA.left, AREA.top, WIDTH, AREA.bottom - AREA.top);
    ctx.setLineDash([]);
    ctx.fillStyle = '#DFE9E2';
    ctx.beginPath();
    for (let x = AREA.left + 24; x < AREA.right; x += 42) {
      for (let y = AREA.top + 24; y < AREA.bottom; y += 42) {
        ctx.moveTo(x + 1.15, y);
        ctx.arc(x, y, 1.15, 0, 2 * Math.PI);
      }
    }
    ctx.fill();
  }

  ctx.beginPath();
  ctx.rect(AREA.left - 2, AREA.top - 2, WIDTH + 4, AREA.bottom - AREA.top + 4);
  ctx.clip();
  const edges = relationGeometry(elements);
  for (const item of elements) {
    if (item.type === 'relation' && edges.has(item.id)) line(ctx, item, edges.get(item.id), item.id === selected);
  }
  for (const item of elements) {
    if (item.type === 'relation') continue;
    if (item.type === 'stroke') {
      stroke(ctx, item, item.id === selected);
      continue;
    }
    writeBox(ctx, item);
    if (item.id === selected || item.id === start) {
      boxPath(ctx, item.x - 5, item.y - 5, item.width + 10, item.height + 10, 15);
      ctx.lineWidth = 4;
      ctx.strokeStyle = GREEN;
      ctx.stroke();
    }
  }
  for (const item of elements) {
    if (item.type === 'relation' && (item.label || item.id === selected) && edges.has(item.id)) {
      lineLabel(ctx, item, edges.get(item.id), item.id === selected);
    }
  }
  if (previewStroke) stroke(ctx, previewStroke, false);
  ctx.restore();
}

export function hitItem(ctx, elements, point, radius, selected, { people = false, eraser = false } = {}) {
  const backToFront = [...elements].reverse();
  if (eraser) return backToFront.find(item => item.type === 'stroke' && nearStroke(point, item, radius));
  if (people) return backToFront.find(item => item.type === 'person' && contains(item, point));
  const geometry = relationGeometry(elements);
  for (const item of backToFront) {
    if (item.type !== 'relation' || (!item.label && item.id !== selected)) continue;
    const path = geometry.get(item.id);
    if (path && contains(labelBounds(ctx, item, path), point, radius / 2)) return item;
  }
  for (const item of backToFront) {
    if (item.type === 'stroke' && nearStroke(point, item, radius)) return item;
    if (isBox(item) && contains(item, point)) return item;
  }
  return backToFront.find(item => item.type === 'relation' && geometry.has(item.id) &&
    nearCurve(point, geometry.get(item.id), radius));
}
