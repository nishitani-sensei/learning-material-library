import { AREA, PAGE, clamp, newId, placeBox, replaceElement, deleteElement, isBox, resizeBox } from './model.js';
import { drawPaper, hitItem, labelBounds } from './draw.js';
import { contains, paperPoint, onPaper, relationGeometry } from './geometry.js';

const modes = { select: 'タップで選ぶ・ドラッグで動かす', hand: '紙面をドラッグして動かす',
  relation: '線をつなぐ1人目をタップ', pen: '指やペンで自由にかく', erase: '消したい手書きの線をタップ' };

const handleOffset = 8;
const handleRadius = 12;

export function makeBoard(canvas, controls) {
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('相関図を表示できません。このページを開き直してください。');
  const pointers = new Map();
  const view = { x: 0, y: 0, fit: 1, zoom: 1, width: 0, height: 0 };
  let mode = 'select';
  let active;
  let pinch;
  let suspended = false;
  let raf;
  let ratio = 1;
  let start = '';

  const scale = () => view.fit * view.zoom;
  const selected = () => controls.state().selected;
  const local = (event, box = canvas.getBoundingClientRect()) => ({ x: event.clientX - box.left, y: event.clientY - box.top });
  const toPaper = screen => ({ x: (screen.x - view.x) / scale(), y: (screen.y - view.y) / scale() });
  const screenMiddle = () => ({ x: view.width / 2, y: view.height / 2 });

  function handle(box) {
    return { x: view.x + (box.x + box.width) * scale() + handleOffset,
      y: view.y + (box.y + box.height) * scale() + handleOffset };
  }

  function hitHandle(point, pointerType) {
    if (mode !== 'select') return;
    const item = controls.state().scene?.elements.find(element => element.id === selected());
    if (!isBox(item)) return;
    const { x, y } = handle(item);
    const radius = pointerType === 'touch' ? 22 : handleRadius + 2;
    if (Math.abs(point.x - x) <= radius && Math.abs(point.y - y) <= radius) return item;
  }

  function drawHandle(box) {
    const { x, y } = handle(box);
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    ctx.arc(0, 0, handleRadius, 0, 2 * Math.PI);
    ctx.fillStyle = '#195339';
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-5, -5);
    ctx.lineTo(5, 5);
    ctx.moveTo(-5, 0);
    ctx.lineTo(-5, -5);
    ctx.lineTo(0, -5);
    ctx.moveTo(5, 0);
    ctx.lineTo(5, 5);
    ctx.lineTo(0, 5);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
  }

  function paint() {
    raf = undefined;
    const { work, scene } = controls.state();
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, view.width, view.height);
    if (!work || !scene) return;
    ctx.save();
    ctx.translate(view.x, view.y);
    ctx.scale(scale(), scale());
    ctx.shadowColor = '#1B443532';
    ctx.shadowBlur = 11;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, PAGE.width, PAGE.height);
    ctx.shadowBlur = 0;
    const elements = active?.preview ?? scene.elements;
    drawPaper(ctx, work.title, scene.name, elements, { editing: true, selected: selected(), start, previewStroke: active?.stroke });
    ctx.restore();
    const box = mode === 'select' && elements.find(element => element.id === selected());
    if (isBox(box)) drawHandle(box);
  }

  function draw() {
    if (raf === undefined) raf = requestAnimationFrame(paint);
  }

  function constrainView() {
    const bound = (offset, windowSize, pageSize) => {
      const edge = Math.min(55, windowSize / 3, pageSize / 2);
      return clamp(offset, edge - pageSize, windowSize - edge);
    };
    view.x = bound(view.x, view.width, PAGE.width * scale());
    view.y = bound(view.y, view.height, PAGE.height * scale());
  }

  function zoomAt(zoom, center, paper = toPaper(center)) {
    view.zoom = clamp(zoom, 0.5, 3);
    view.x = center.x - paper.x * scale();
    view.y = center.y - paper.y * scale();
    constrainView();
    controls.zoom(view.zoom);
    draw();
  }

  function fit() {
    view.zoom = 1;
    view.x = (view.width - PAGE.width * scale()) / 2;
    view.y = (view.height - PAGE.height * scale()) / 2;
    controls.zoom(1);
    draw();
  }

  function resize() {
    const { width, height } = canvas.getBoundingClientRect();
    if (!width || !height || (view.width === width && view.height === height)) return;
    const center = view.width ? toPaper(screenMiddle()) : null;
    if (pointers.size) cancel();
    view.width = width;
    view.height = height;
    ratio = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    view.fit = Math.min(Math.max(1, width - 32) / PAGE.width, Math.max(1, height - 32) / PAGE.height);
    if (center && view.zoom !== 1) zoomAt(view.zoom, screenMiddle(), center);
    else fit();
  }

  function changeMode(next) {
    cancel();
    start = '';
    mode = next;
    canvas.dataset.mode = mode;
    controls.hint(modes[mode]);
    draw();
  }

  function touchPair() {
    const pair = [...pointers.values()].filter(item => item.type === 'touch').slice(0, 2);
    if (pair.length < 2) return null;
    const [a, b] = pair;
    return { center: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, distance: Math.max(1, Math.hypot(b.x - a.x, b.y - a.y)) };
  }

  function cancel() {
    active = undefined;
    pinch = undefined;
    suspended = false;
    canvas.style.cursor = '';
    for (const id of pointers.keys()) {
      pointers.delete(id);
      if (canvas.hasPointerCapture(id)) canvas.releasePointerCapture(id);
    }
    draw();
  }

  function pointFor(event, bounds) {
    const point = paperPoint(toPaper(local(event, bounds)));
    if (event.pointerType === 'pen' && event.pressure > 0) point.pressure = Math.round(event.pressure * 100) / 100;
    return point;
  }

  function down(event) {
    if (event.button !== 0 || !controls.state().scene || controls.blocked()) return;
    event.preventDefault();
    const point = local(event);
    pointers.set(event.pointerId, { ...point, type: event.pointerType });
    canvas.setPointerCapture(event.pointerId);
    const pair = touchPair();
    if (pair) {
      if (!pinch) {
        active = undefined;
        canvas.style.cursor = '';
        pinch = { ...pair, zoom: view.zoom, anchor: toPaper(pair.center) };
        suspended = true;
        draw();
      }
      return;
    }
    if (suspended || active) return;

    const { scene, pen, budget } = controls.state();
    const paper = toPaper(point);
    const hit = options => hitItem(ctx, scene.elements, paper, 10 / scale(), selected(), options);
    const gesture = { id: event.pointerId, down: point, paper, original: scene.elements, moved: false };
    switch (mode) {
      case 'hand':
        active = { ...gesture, kind: 'pan', x: view.x, y: view.y };
        break;
      case 'pen':
        if (onPaper(paper) && budget > 0) {
          active = { ...gesture, kind: 'draw', budget, stroke: { id: newId(), type: 'stroke',
            points: [pointFor(event)], color: pen.color, strokeWidth: pen.width } };
        } else if (onPaper(paper)) controls.limit();
        break;
      case 'erase':
        active = { ...gesture, kind: 'erase', item: hit({ eraser: true }) };
        if (active.item) active.preview = deleteElement(scene.elements, active.item.id);
        draw();
        break;
      case 'relation':
        active = { ...gesture, kind: 'connect', item: hit({ people: true }) };
        break;
      default: {
        const box = hitHandle(point, event.pointerType);
        if (box) {
          active = { ...gesture, kind: 'resize', item: box };
          canvas.style.cursor = 'nwse-resize';
          break;
        }
        const item = hit();
        controls.select(item?.id ?? '');
        let canDrag = isBox(item);
        let label;
        if (item?.type === 'relation') {
          const path = relationGeometry(scene.elements).get(item.id);
          label = labelBounds(ctx, item, path);
          canDrag = contains(label, paper, 10 / scale());
        }
        active = { ...gesture, kind: 'select', item, canDrag, label };
        break;
      }
    }
  }

  function move(event) {
    const existing = pointers.get(event.pointerId);
    if (!existing) {
      if (event.pointerType === 'mouse') canvas.style.cursor = hitHandle(local(event), 'mouse') ? 'nwse-resize' : '';
      return;
    }
    const bounds = canvas.getBoundingClientRect();
    const point = local(event, bounds);
    Object.assign(existing, point);
    const pair = touchPair();
    if (pinch && pair) {
      zoomAt(pinch.zoom * pair.distance / pinch.distance, pair.center, pinch.anchor);
      return;
    }
    if (!active || event.pointerId !== active.id) return;
    const state = active;
    const dx = point.x - state.down.x;
    const dy = point.y - state.down.y;
    state.moved ||= Math.hypot(dx, dy) > 4;
    if (state.kind === 'pan') {
      view.x = state.x + dx;
      view.y = state.y + dy;
      constrainView();
    } else if (state.kind === 'resize' && state.moved) {
      const resized = resizeBox(state.item, dx / scale(), dy / scale());
      const { width, height } = state.item;
      state.preview = resized.width === width && resized.height === height ? undefined : replaceElement(state.original, resized);
    } else if (state.kind === 'draw') {
      const events = event.getCoalescedEvents?.();
      for (const sample of events?.length ? events : [event]) {
        const next = pointFor(sample, bounds);
        const points = state.stroke.points;
        const last = points[points.length - 1];
        if (points.length < state.budget && Math.hypot(next.x - last.x, next.y - last.y) >= 0.9) points.push(next);
        else if (points.length >= state.budget) controls.limit();
      }
    } else if (state.kind === 'erase' && !state.item) {
      state.item = hitItem(ctx, state.original, toPaper(point), 10 / scale(), '', { eraser: true });
      if (state.item) state.preview = deleteElement(state.original, state.item.id);
    } else if (state.kind === 'select' && state.moved && state.canDrag) {
      const { item, label } = state;
      let moved;
      if (label) {
        const anchor = relationGeometry(state.original).get(item.id).base;
        const x = clamp(label.x + dx / scale(), AREA.left + 3, AREA.right - label.width - 3);
        const y = clamp(label.y + dy / scale(), AREA.top + 3, AREA.bottom - label.height - 3);
        moved = { ...item, labelOffset: { x: x + label.width / 2 - anchor.x, y: y + label.height / 2 - anchor.y } };
      } else {
        moved = placeBox({ ...item, x: item.x + dx / scale(), y: item.y + dy / scale() });
      }
      state.preview = replaceElement(state.original, moved);
    }
    draw();
  }

  function finish(event) {
    if (!pointers.has(event.pointerId)) return;
    move(event);
    pointers.delete(event.pointerId);
    if (pinch || suspended) {
      if (!pointers.size) { pinch = undefined; suspended = false; }
      return;
    }
    if (!active || event.pointerId !== active.id) return;
    const gesture = active;
    active = undefined;
    if (gesture.kind === 'resize') canvas.style.cursor = '';
    if (gesture.kind === 'draw') {
      controls.commit([...gesture.original, gesture.stroke]);
    } else if (gesture.kind === 'connect' && !gesture.moved) {
      const id = gesture.item?.id;
      if (id && start && id !== start) {
        const from = start;
        start = '';
        controls.hint(modes.relation);
        controls.connect(from, id);
      } else if (id) {
        start = start === id ? '' : id;
        controls.hint(start ? '線をつなぐ2人目をタップ' : modes.relation);
      }
    } else if (gesture.preview) {
      controls.commit(gesture.preview);
      if (gesture.kind === 'erase' && selected() === gesture.item.id) controls.select('');
    }
    draw();
  }

  function cancelled(event) {
    if (pointers.has(event.pointerId)) cancel();
  }

  canvas.addEventListener('pointerdown', down);
  canvas.addEventListener('pointermove', move);
  canvas.addEventListener('pointerup', finish);
  canvas.addEventListener('pointercancel', cancelled);
  canvas.addEventListener('lostpointercapture', cancelled);
  canvas.addEventListener('contextmenu', event => event.preventDefault());
  new ResizeObserver(resize).observe(canvas);
  window.addEventListener('orientationchange', cancel);
  window.addEventListener('blur', cancel);

  return { ctx, draw, resize, fit, cancel, changeMode, zoom: increment => zoomAt(view.zoom + increment, screenMiddle()),
    center: () => toPaper(screenMiddle()) };
}
