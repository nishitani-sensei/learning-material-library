export const $ = id => document.getElementById(id);
let nextField = 0;

export function node(tag, text = '', className = '') {
  const element = document.createElement(tag);
  element.textContent = text;
  if (className) element.className = className;
  return element;
}

export function button(label, action, className = '') {
  const element = node('button', label, className);
  element.type = 'button';
  element.addEventListener('click', action);
  return element;
}

export function field(label, control) {
  const container = node('div', '', 'field');
  const caption = node('label', label);
  control.id = 'dialog-field-' + ++nextField;
  caption.htmlFor = control.id;
  container.append(caption, control);
  return container;
}

export function input(type, value, options = {}) {
  return Object.assign(node('input'), { type, value, ...options });
}

export function choice(options, selected) {
  const element = node('select');
  for (const [value, label] of options) element.add(new Option(label, value));
  element.value = selected;
  return element;
}

export function dialog(title) {
  const modal = $('modal');
  $('modal-title').textContent = title;
  $('modal-body').replaceChildren();
  if (!modal.open) modal.showModal();
  return $('modal-body');
}

export function closeDialog() { $('modal').close(); }

export function showChoices(title, entries, message) {
  const body = dialog(title);
  const actions = node('div', '', 'choice-list');
  if (message) body.append(node('p', message));
  for (const entry of entries) {
    const item = button(entry.label, entry.action, entry.className);
    if (entry.color) item.style.setProperty('--note', entry.color);
    actions.append(item);
  }
  body.append(actions);
  actions.querySelector('button')?.focus();
}

export function showForm({ title, message, fields = [], confirm = '決定', onSubmit, danger = false }) {
  const body = dialog(title);
  const form = node('form');
  const error = node('div', '', 'form-error');
  error.setAttribute('role', 'alert');
  if (message) form.append(node('p', message));
  const group = node('div', '', 'form-fields');
  group.append(...fields, error);
  form.append(group);

  const cancel = button('やめる', closeDialog);
  const submit = node('button', confirm, danger ? 'danger-text' : 'primary');
  submit.type = 'submit';
  const actions = node('div', '', 'form-actions');
  actions.append(cancel, submit);
  form.append(actions);
  body.append(form);

  let composing = false;
  let imeEnter = false;
  form.addEventListener('compositionstart', () => { composing = true; });
  form.addEventListener('compositionend', () => { composing = false; });
  form.addEventListener('keydown', event => {
    if (event.key === 'Enter' && (composing || event.isComposing || event.keyCode === 229)) {
      // Let the IME handle candidate selection, suppress only implicit form submission.
      imeEnter = true;
      setTimeout(() => { imeEnter = false; }, 0);
    }
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (composing || imeEnter || submit.disabled) return;
    error.textContent = '';
    submit.disabled = true;
    cancel.disabled = true;
    $('close-modal').disabled = true;
    try {
      await onSubmit();
      if ($('modal-body').contains(form)) closeDialog();
    } catch (reason) {
      error.textContent = reason.message || '操作を完了できませんでした。';
    } finally {
      $('close-modal').disabled = false;
      submit.disabled = false;
      cancel.disabled = false;
    }
  });
  // Calling focus synchronously from the tap also brings up the iPad keyboard.
  (form.querySelector('input[type="text"], textarea') ?? cancel).focus();
}

export function installToolIcons() {
  const icons = {
    select: '<path d="m4 3 15 9-7 1.5L9 20 4 3Z"/>',
    person: '<circle cx="10" cy="6" r="3"/><path d="M4 19v-2a6 6 0 0 1 12 0v2H4Zm14-9h5m-2.5-2.5v5"/>',
    relation: '<circle cx="4" cy="12" r="2"/><path d="M7 12h12m-4-4 4 4-4 4"/>',
    note: '<path d="M4 4h16v11l-5 5H4V4Z m11 16v-5h5M8 9h8m-8 4h4"/>',
    text: '<path d="M4 7V4h16v3M12 4v16m-4 0h8"/>',
    pen: '<path d="m14 5 5 5m-15 9 1-5L16 3l5 5-11 11-6 1Z"/>',
    erase: '<path d="m5 14 8-9a2 2 0 0 1 2.8 0l5 4a2 2 0 0 1 0 2.8L13 20H9l-4-4a1.5 1.5 0 0 1 0-2Zm4-4 8 7m-4 3h8"/>',
    hand: '<path d="M3 12h18M12 3v18m-6-6-3-3 3-3m12 0 3 3-3 3m-9 3 3 3 3-3m0-12-3-3-3 3"/>',
    undo: '<path d="m8 5-4 5 4 4m-4-4h10a5 5 0 0 1 0 10h-2"/>',
    redo: '<path d="m16 5 4 5-4 4m4-4H10a5 5 0 0 0 0 10h2"/>',
  };
  for (const element of document.querySelectorAll('[data-icon]')) {
    element.insertAdjacentHTML('afterbegin', '<svg viewBox="0 0 24 24" aria-hidden="true">' + icons[element.dataset.icon] + '</svg>');
  }
}
