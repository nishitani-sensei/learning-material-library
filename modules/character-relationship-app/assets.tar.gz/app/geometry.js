import { AREA, clamp } from './model.js';

export const middle = box => ({ x: box.x + box.width / 2, y: box.y + box.height / 2 });
export const contains = (box, point, extra = 0) => point.x >= box.x - extra && point.x <= box.x + box.width + extra &&
  point.y >= box.y - extra && point.y <= box.y + box.height + extra;

function edge(box, center, toward) {
  const dx = toward.x - center.x;
  const dy = toward.y - center.y;
  const factor = 1 / Math.max(Math.abs(dx) / (box.width / 2), Math.abs(dy) / (box.height / 2));
  return Number.isFinite(factor) ? { x: center.x + dx * factor, y: center.y + dy * factor } : center;
}

export function curvePoint({ start, bend, end }, t) {
  const rest = 1 - t;
  return { x: rest * rest * start.x + 2 * t * rest * bend.x + t * t * end.x,
    y: rest * rest * start.y + 2 * t * rest * bend.y + t * t * end.y };
}

export function relationGeometry(elements) {
  const people = new Map();
  const groups = new Map();
  for (const element of elements) {
    if (element.type === 'person') people.set(element.id, element);
    if (element.type !== 'relation') continue;
    const key = [element.sourceId, element.targetId].sort().join('/');
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(element);
  }

  const geometry = new Map();
  for (const group of groups.values()) {
    group.forEach((relation, index) => {
      const source = people.get(relation.sourceId);
      const target = people.get(relation.targetId);
      if (!source || !target) return;
      const a = middle(source);
      const b = middle(target);
      const dx = b.x - a.x || (b.y === a.y ? 1 : 0);
      const dy = b.y - a.y;
      const length = Math.hypot(dx, dy);
      const lane = (index - (group.length - 1) / 2) * Math.min(76, 440 / Math.max(1, group.length - 1)) *
        (relation.sourceId < relation.targetId ? 1 : -1);
      const bend = { x: clamp((a.x + b.x) / 2 - dy * lane / length, AREA.left, AREA.right),
        y: clamp((a.y + b.y) / 2 + dx * lane / length, AREA.top, AREA.bottom) };
      const start = edge(source, a, bend);
      const end = edge(target, b, bend);
      const curve = { start, bend, end };
      const base = curvePoint(curve, 0.5);
      geometry.set(relation.id, { ...curve, base });
    });
  }
  return geometry;
}

export function distanceToSegment(point, start, end) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const length = dx * dx + dy * dy;
  const t = length ? clamp(((point.x - start.x) * dx + (point.y - start.y) * dy) / length, 0, 1) : 0;
  return Math.hypot(point.x - start.x - t * dx, point.y - start.y - t * dy);
}

export function nearCurve(point, path, radius) {
  let last = path.start;
  for (let i = 1; i <= 16; i++) {
    const next = curvePoint(path, i / 16);
    if (distanceToSegment(point, last, next) <= radius) return true;
    last = next;
  }
  return false;
}

export function nearStroke(point, stroke, radius) {
  const tolerance = radius + stroke.strokeWidth / 2;
  return stroke.points.some((next, i, all) => distanceToSegment(point, all[Math.max(0, i - 1)], next) <= tolerance);
}

export function paperPoint(point) {
  return { x: clamp(Math.round(point.x * 10) / 10, AREA.left, AREA.right),
    y: clamp(Math.round(point.y * 10) / 10, AREA.top, AREA.bottom) };
}

export const onPaper = point => point.x >= AREA.left && point.x <= AREA.right && point.y >= AREA.top && point.y <= AREA.bottom;
