export class History {
  past = [];
  future = [];

  add(before) {
    this.past.push(before);
    if (this.past.length > 50) this.past.shift();
    this.future.length = 0;
  }

  undo(current) {
    if (!this.past.length) return current;
    this.future.push(current);
    return this.past.pop();
  }

  redo(current) {
    if (!this.future.length) return current;
    this.past.push(current);
    return this.future.pop();
  }
}
