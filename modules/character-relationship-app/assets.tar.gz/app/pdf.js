import { PAGE, ordered, safeFileName } from './model.js';
import { drawPaper } from './draw.js';

export const A4 = [297 * 72 / 25.4, 210 * 72 / 25.4];

async function renderImage(title, scene, factor) {
  const canvas = document.createElement('canvas');
  canvas.width = PAGE.width * factor;
  canvas.height = PAGE.height * factor;
  try {
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('PDF用の紙面を作れませんでした。');
    ctx.scale(factor, factor);
    drawPaper(ctx, title, scene.name, scene.elements);
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.94));
    if (!blob) throw new Error('PDF用の画像を作れませんでした。');
    return blob.arrayBuffer();
  } finally {
    // In Safari, drop the canvas backing store as soon as its image is encoded.
    canvas.width = 0;
    canvas.height = 0;
  }
}

export async function makePdf(work, scenes, { lowResolution = false, progress = () => {}, image = renderImage } = {}) {
  const { PDFDocument } = await import('../vendor/pdf-lib.js');
  const pdf = await PDFDocument.create();
  pdf.setTitle(work.title + ' - 人物相関図');
  const sequence = ordered(scenes);
  for (const [index, scene] of sequence.entries()) {
    progress(index + 1, sequence.length);
    await new Promise(resolve => setTimeout(resolve, 0));
    const jpg = await pdf.embedJpg(await image(work.title, scene, lowResolution ? 1 : 2));
    const page = pdf.addPage(A4);
    page.drawImage(jpg, { x: 0, y: 0, width: A4[0], height: A4[1] });
    await jpg.embed();
  }
  return new Blob([await pdf.save()], { type: 'application/pdf' });
}

export function attachFile(container, blob, title, extension) {
  const fileName = safeFileName(title, extension);
  const url = URL.createObjectURL(blob);
  const download = document.createElement('a');
  download.className = 'button primary';
  download.textContent = extension === 'pdf' ? 'PDFを保存する' : 'JSONを保存する';
  download.href = url;
  download.download = fileName;
  container.append(download);
  if (extension === 'pdf') {
    const preview = document.createElement('a');
    preview.className = 'button';
    preview.href = url;
    preview.target = '_blank';
    preview.rel = 'noopener';
    preview.textContent = 'PDFを開く';
    container.append(preview);
  }
  const file = new File([blob], fileName, { type: blob.type });
  if (navigator.canShare?.({ files: [file] })) {
    const share = document.createElement('button');
    share.textContent = '共有・ファイルに保存';
    share.type = 'button';
    share.onclick = async () => {
      try { await navigator.share({ files: [file] }); }
      catch (error) { if (error.name !== 'AbortError') download.focus(); }
    };
    container.append(share);
  }
  return () => setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
