import { inLibrary } from './config.js';
import { PAGE, AREA, BOX_MIN, LIMIT, NOTE, PALETTE, INKS, LINE_TYPES, checkName, createWork, newScene, duplicateWork, isBox,
  duplicateElements, checkLimits, placeBox, now, newId, reindex, replaceElement, deleteElement } from './model.js';
import { openStore, ConflictError } from './store.js';
import { Autosave } from './autosave.js';
import { History } from './history.js';
import { $ , node, button, field, input, choice, dialog, closeDialog, showForm, showChoices, installToolIcons } from './ui.js';
import { makeBoard } from './board.js';
import { drawPaper, naturalBoxTextHeight } from './draw.js';
import { example } from './example.js';
import { readBackup, jsonFile } from './backup.js';
import { makePdf, attachFile } from './pdf.js';

const statusText = { dirty: '変更あり', saving: '保存中…', saved: '保存済み', error: '保存できませんでした' };
const colorNames = ['黒', '赤', '青', '緑'];
const penColors = INKS.slice(0, 4);
const pen = { color: penColors[0], width: 7 };
const histories = new Map();
const openButton = $('open-works');
let store;
let dataset;
let sceneId;
let autosave;
let selected = '';
let mode = 'select';
let busy = false;
let blocked = false;
let restoreAction;
let releaseFile;
let toastTimer;
let limitNotice = 0;
let strokeBudget = LIMIT.points;

const state = () => ({ work: dataset?.work, scene: dataset?.scenes.find(scene => scene.id === sceneId),
  selected, pen, budget: strokeBudget });
const current = () => state().scene;
const history = () => {
  if (!histories.has(sceneId)) histories.set(sceneId, new History());
  return histories.get(sceneId);
};

const board = makeBoard($('board'), {
  state, blocked: () => busy || $('modal').open, select,
  hint: text => { $('tool-hint').textContent = text; },
  zoom: zoom => { $('zoom-fit').textContent = Math.round(zoom * 100) + '%'; },
  connect: (sourceId, targetId) => editRelation({ sourceId, targetId }),
  commit: elements => {
    try { commit(elements); } catch (error) { toast(error.message); }
  },
  limit: () => {
    if (Date.now() - limitNotice > 1500) {
      limitNotice = Date.now();
      toast('この場面に保存できる手書きの量が上限に達しました。');
    }
  },
});

function listen(id, event, callback) { $(id).addEventListener(event, callback); }
const click = (id, action) => listen(id, 'click', action);

function toast(message, persistent = false) {
  clearTimeout(toastTimer);
  $('toast-text').textContent = message;
  $('restore-deleted').hidden = !restoreAction;
  $('toast').hidden = false;
  if (!persistent && !restoreAction) toastTimer = setTimeout(() => { $('toast').hidden = true; }, 5200);
}

function saveStatus(status, error) {
  const label = $('save-status');
  label.dataset.state = status;
  label.textContent = statusText[status];
  blocked = error instanceof ConflictError;
  $('save-error').hidden = status !== 'error';
  $('reopen').hidden = !blocked;
  $('retry-save').hidden = blocked;
  if (status === 'error') {
    $('save-error-text').textContent = blocked ? error.message :
      error?.name === 'QuotaExceededError' ? '端末の保存容量が足りません。JSONを保存し、空き容量を確かめてください。' :
      '変更はこの画面に残っています。もう一度保存するか、JSONを保存してください。';
  }
}

async function critical(action) {
  if (busy) throw new Error('処理が終わるまでお待ちください。');
  busy = true;
  board.cancel();
  try { return await action(); }
  catch (error) {
    if (dataset && error instanceof ConflictError) autosave.block(error);
    throw error;
  }
  finally { busy = false; }
}

function run(action) {
  if (busy) return;
  void critical(action).catch(error => {
    if (error instanceof ConflictError || !autosave?.dirty) {
      toast(error.message || '操作を完了できませんでした。');
    } else {
      toast('保存を確認できませんでした。作品は編集中の画面に残っています。');
    }
  });
}

function showScreen(screen) {
  $('start').hidden = screen === 'editor';
  $('editor').hidden = screen !== 'editor';
  $('home').hidden = screen !== 'home';
  $('works').hidden = screen !== 'works';
}

function shutdownEditor() {
  autosave?.dispose();
  autosave = undefined;
  dataset = undefined;
  sceneId = undefined;
  histories.clear();
  board.cancel();
}

function goHome() {
  shutdownEditor();
  showScreen('home');
}

async function showWorks() {
  const list = await store.list();
  const cards = $('work-cards');
  cards.replaceChildren();
  if (!list.length) cards.append(node('p', 'まだ作品がありません。「新しい相関図」から始めましょう。'));
  for (const entry of list) {
    const card = node('article', '', 'work-card');
    const date = new Date(entry.updatedAt).toLocaleString('ja-JP', {
      year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit',
    });
    const actions = node('div', '', 'card-actions');
    actions.append(
      button('編集する', () => run(async () => {
        const result = await readWork(entry.id);
        if (result.scenes.length === 1) { showEditor(result); return; }
        showChoices('どの場面を開く？', result.scenes.map((scene, index) => ({
          label: (index + 1) + '. ' + scene.name,
          action: () => run(async () => {
            const fresh = await readWork(entry.id);
            if (!fresh.scenes.some(item => item.id === scene.id)) {
              closeDialog();
              await showWorks();
              throw new Error('場面が変更されました。もう一度選んでください。');
            }
            closeDialog();
            showEditor(fresh, scene.id);
          }),
        })));
      }), 'primary'),
      button('名前変更', () => renameWork(entry)),
      button('複製', () => run(async () => {
        const result = await readWork(entry.id);
        const title = Array.from(result.work.title).slice(0, 45).join('') + '（コピー）';
        const copy = duplicateWork(result, title);
        checkLimits(copy.work, copy.scenes);
        await store.add(copy.work, copy.scenes);
        await showWorks();
        toast('作品を複製しました。');
      })),
      button('削除', () => removeWork(entry), 'danger-text'),
    );
    card.append(node('h2', entry.title), node('p', entry.count + '場面　・　最終編集 ' + date), actions);
    cards.append(card);
  }
  shutdownEditor();
  showScreen('works');
}

async function readWork(id) {
  const result = await store.read(id);
  if (!result || !result.scenes.length) throw new Error('作品が見つかりませんでした。作品一覧で選び直してください。');
  return result;
}

function titleForm(label, initial, max) {
  const control = input('text', initial, { autocomplete: 'off', required: true, maxLength: max * 2 });
  return { control, field: field(label, control), name: () => checkName(control.value, max, label) };
}

function create() {
  const title = titleForm('作品名', '', 50);
  title.control.placeholder = '例　森の小さな手紙';
  const name = titleForm('最初の場面名', '第1場面', 30);
  showForm({ title: '新しい相関図', fields: [title.field, name.field], confirm: '作成する', onSubmit: () => critical(async () => {
    const next = createWork(title.name(), name.name());
    await store.add(next.work, next.scenes);
    showEditor(next);
  }) });
}

function renameWork(entry) {
  const title = titleForm('作品名', entry.title, 50);
  showForm({ title: '作品名を変更', fields: [title.field], confirm: '変更する', onSubmit: () => critical(async () => {
    const proposed = title.name();
    if (proposed !== entry.title) {
      const currentWork = await readWork(entry.id);
      if (currentWork.work.revision !== entry.revision) throw new ConflictError();
      checkLimits({ ...entry, title: proposed }, currentWork.scenes);
      await store.change(entry, { title: proposed });
      await showWorks();
    }
  }) });
}

function removeWork(entry) {
  showForm({ title: '作品を削除しますか？', message: '「' + entry.title + '」のすべての場面を削除します。',
    confirm: '作品を削除', danger: true, onSubmit: () => critical(async () => {
      const item = await readWork(entry.id);
      const removed = await store.change(entry, { deleteWork: true, remove: item.scenes.map(scene => scene.id) });
      restoreAction = async () => {
        await store.add({ ...item.work, revision: removed.revision + 1, updatedAt: now() }, item.scenes);
        if (!$('works').hidden) await showWorks();
      };
      await showWorks();
      toast('作品を削除しました。', true);
    }) });
}

function showEditor(result, id = result.scenes[0].id) {
  shutdownEditor();
  dataset = result;
  autosave = new Autosave(async scene => {
    dataset.work = await store.change(dataset.work, { put: [scene] });
  }, saveStatus);
  saveStatus('saved');
  showScreen('editor');
  showScene(id);
}

function showScene(id) {
  sceneId = id;
  select('');
  setMode('select');
  renderSceneDetails();
  board.resize();
  board.fit();
  refreshEdits();
}

function renderSceneDetails() {
  const { work, scene } = state();
  $('work-title').textContent = work.title;
  $('work-title').title = work.title;
  $('scene-title').textContent = scene.name;
  $('scene-title').title = scene.name;
  const selectScene = $('scene-select');
  selectScene.replaceChildren(...dataset.scenes.map((entry, index) =>
    new Option((index + 1) + '. ' + entry.name, entry.id, false, entry.id === sceneId)));
}

function selectedItem() { return current()?.elements.find(item => item.id === selected); }

function select(id) {
  selected = id;
  const item = selectedItem();
  const label = item?.name ?? (item?.type === 'note' ? NOTE[item.noteType].label :
    item?.type === 'relation' ? (item.label || '関係線') : item?.type === 'text' ? '文字' : '手書き');
  $('selection-actions').hidden = !item || mode !== 'select';
  $('selection-label').textContent = item ? label : '';
  $('edit-item').hidden = item?.type === 'stroke';
  if (mode === 'select') {
    $('tool-hint').textContent = isBox(item) ?
      '中をドラッグして移動・右下の取っ手で大きさを変更' : 'タップで選ぶ・ドラッグで動かす';
  }
  board.draw();
}

function setMode(next) {
  mode = next;
  board.changeMode(next);
  select(next === 'select' ? selected : '');
  for (const element of document.querySelectorAll('[data-mode]')) {
    if (element.tagName === 'BUTTON') element.setAttribute('aria-pressed', String(element.dataset.mode === next));
  }
  $('pen-settings').hidden = next !== 'pen';
}

function refreshEdits() {
  const live = current();
  strokeBudget = LIMIT.points - live.elements.reduce((sum, element) => sum + (element.points?.length ?? 0), 0);
  $('undo').disabled = !history().past.length;
  $('redo').disabled = !history().future.length;
  select(selectedItem() ? selected : '');
}

function commit(elements, record = true) {
  const scene = current();
  if (elements === scene.elements) return;
  const updated = { ...scene, elements, updatedAt: now() };
  const proposed = dataset.scenes.map(value => value.id === updated.id ? updated : value);
  checkLimits(dataset.work, proposed);
  if (record) history().add(scene.elements);
  dataset.scenes = proposed;
  autosave.change(updated);
  refreshEdits();
}

function historyStep(direction) {
  const record = history();
  const prior = current().elements;
  const next = record[direction](prior);
  try { commit(next, false); }
  catch (error) {
    record[direction === 'undo' ? 'redo' : 'undo'](next);
    toast(error.message);
  }
}

function createPlace(kind, noteType) {
  const dimensions = { person: [230, 108], note: [320, 154], text: [460, 130] };
  const [width, height] = dimensions[kind];
  const center = board.center();
  const count = current().elements.length;
  const delta = (count % 5) * 43;
  const box = placeBox({ id: newId(), type: kind, x: center.x - width / 2 - 90 + delta,
    y: center.y - height / 2 - 74 + delta, width, height });
  if (kind === 'person') return { ...box, name: '', fillColor: PALETTE[0], borderColor: '#68937B' };
  if (kind === 'note') return { ...box, noteType, text: '', fillColor: NOTE[noteType].color };
  return { ...box, text: '', color: INKS[0], fontSize: 34 };
}

function editBox(kind, original, noteType) {
  const box = original ?? createPlace(kind, noteType);
  const isPerson = kind === 'person';
  const isText = kind === 'text';
  const description = isPerson ? '人物' : isText ? '文字' : NOTE[box.noteType].label;
  const text = isPerson ? input('text', box.name, { maxLength: 100, required: true }) :
    Object.assign(node('textarea'), { value: box.text, maxLength: 2000, required: true, rows: 4 });
  const dimensions = node('div', '', 'field-grid');
  const width = input('number', String(Math.round(box.width)), { min: BOX_MIN.width, max: AREA.right - AREA.left, required: true });
  const height = input('number', String(Math.round(box.height)), { min: BOX_MIN.height, max: AREA.bottom - AREA.top, required: true });
  dimensions.append(field('横の長さ', width), field('たての長さ', height));

  const color = input('color', isText ? box.color : box.fillColor);
  const fields = [field(isPerson ? '人物名' : isText ? '入れたい文字' : 'メモの内容', text), field(isText ? '文字の色' : '色', color), dimensions];
  const font = input('number', String(box.fontSize ?? 34), { min: 18, max: 64, required: true });
  if (isText) fields.push(field('文字の大きさ', font));
  showForm({ title: description + (original ? 'を編集' : 'を追加'), fields,
    confirm: original ? '変更する' : '追加する', onSubmit: () => {
      const changed = placeBox({ ...box, width: Number(width.value), height: Number(height.value) });
      if (isPerson) changed.name = checkName(text.value, 50, '人物名');
      else changed.text = checkName(text.value, 1000, '内容');
      if (isText) {
        changed.color = color.value;
        changed.fontSize = Number(font.value);
      } else {
        changed.fillColor = color.value;
      }
      const defaultSize = !original && Number(width.value) === Math.round(box.width) && Number(height.value) === Math.round(box.height);
      const next = defaultSize ?
        placeBox({ ...changed, height: Math.max(changed.height, Math.ceil(naturalBoxTextHeight(board.ctx, changed))) }) : changed;
      commit(original ? replaceElement(current().elements, next) : [...current().elements, next]);
      setMode('select');
      select(next.id);
    } });
}

function editRelation({ sourceId, targetId }, original) {
  const names = current().elements.filter(item => item.type === 'person');
  const first = names.find(item => item.id === sourceId);
  const last = names.find(item => item.id === targetId);
  if (!first || !last) return;
  const label = input('text', original?.label ?? '', { maxLength: 120 });
  label.placeholder = '例　たすける（空欄でも使えます）';
  const styles = Object.entries(LINE_TYPES);
  const oldStyle = original ? styles.find(([, style]) => style.lineStyle === original.lineStyle &&
    style.arrowMode === original.arrowMode)[0] : 'arrow';
  const style = choice(styles.map(([value, entry]) => [value, entry.label]), oldStyle);
  const color = input('color', original?.color ?? INKS[0]);
  showForm({ title: original ? '関係線を編集' : '関係線を追加', message: first.name + ' と ' + last.name,
    fields: [field('線に書くことば', label), field('線の種類', style), field('線の色', color)],
    confirm: original ? '変更する' : '線をつなぐ', onSubmit: () => {
      const text = label.value.trim();
      if (Array.from(text).length > 60) throw new Error('線に書くことばは60文字までです。');
      const { lineStyle, arrowMode } = LINE_TYPES[style.value];
      const item = { id: original?.id ?? newId(), type: 'relation', sourceId, targetId, label: text, lineStyle, arrowMode,
        color: color.value, labelOffset: original?.labelOffset ?? { x: 0, y: 0 } };
      commit(original ? replaceElement(current().elements, item) : [...current().elements, item]);
      setMode('select');
      select(item.id);
    } });
}

function removeItem() {
  const item = selectedItem();
  if (!item) return;
  const message = item.type === 'person' ? '「' + item.name + '」と、この人物につながる線を削除します。' : '選んだ項目を削除します。';
  showForm({ title: '選んだ項目を削除しますか？', message, confirm: '削除する', danger: true, onSubmit: () => {
    commit(deleteElement(current().elements, item.id));
  } });
}

async function flush() {
  if (autosave) await autosave.flush();
}

async function changeScenes(scenes) {
  await flush();
  const next = reindex(scenes);
  checkLimits(dataset.work, next);
  const before = new Map(dataset.scenes.map(scene => [scene.id, scene]));
  const ids = new Set(next.map(scene => scene.id));
  const put = next.filter(scene => before.get(scene.id) !== scene);
  const remove = dataset.scenes.filter(scene => !ids.has(scene.id)).map(scene => scene.id);
  if (!put.length && !remove.length) return;
  dataset.work = await store.change(dataset.work, { put, remove });
  dataset.scenes = next;
  renderSceneDetails();
}

function newSceneMenu(copyFrom = current()) {
  const open = copy => {
    const name = titleForm('場面名', '第' + (dataset.scenes.length + 1) + '場面', 30);
    showForm({ title: copy ? '今の相関図をコピー' : '白紙の相関図', fields: [name.field], confirm: '場面を作る',
      onSubmit: () => critical(async () => {
        const next = newScene(dataset.work.id, name.name(), dataset.scenes.length,
          copy ? duplicateElements(copyFrom.elements) : []);
        await changeScenes([...dataset.scenes, next]);
        showScene(next.id);
      }) });
  };
  showChoices('次の場面の相関図を作る', [
    { label: '今の場面をコピーして作る', action: () => open(true), className: 'primary' },
    { label: '白紙から作る', action: () => open(false) },
  ], '人物やメモを次の場面に引きつぐか選びます。');
}

function renameScene(entry) {
  const name = titleForm('場面名', entry.name, 30);
  showForm({ title: '場面名を変更', fields: [name.field], confirm: '変更する', onSubmit: () => critical(async () => {
    const value = name.name();
    if (value !== entry.name) {
      await changeScenes(dataset.scenes.map(scene => scene.id === entry.id ? { ...scene, name: value, updatedAt: now() } : scene));
      board.draw();
    }
    manageScenes();
  }) });
}

function removeScene(entry) {
  showForm({ title: '場面を削除しますか？', message: '「' + entry.name + '」を削除します。', confirm: '場面を削除',
    danger: true, onSubmit: () => critical(async () => {
      if (dataset.scenes.length <= 1) throw new Error('作品に最後の1場面を残してください。');
      const index = dataset.scenes.findIndex(scene => scene.id === entry.id);
      const next = dataset.scenes.filter(scene => scene.id !== entry.id);
      const previousId = sceneId;
      if (previousId === entry.id) {
        await flush();
        sceneId = next[Math.min(index, next.length - 1)].id;
      }
      try { await changeScenes(next); }
      catch (error) { sceneId = previousId; throw error; }
      const workId = dataset.work.id;
      histories.delete(entry.id);
      restoreAction = async () => {
        if (dataset?.work.id === workId) {
          const list = [...dataset.scenes];
          list.splice(Math.min(index, list.length), 0, entry);
          await changeScenes(list);
          showScene(entry.id);
          return;
        }
        const saved = await readWork(workId);
        const list = [...saved.scenes];
        list.splice(Math.min(index, list.length), 0, entry);
        const reordered = reindex(list);
        checkLimits(saved.work, reordered);
        await store.change(saved.work, { put: reordered });
        if (!$('works').hidden) await showWorks();
      };
      if (previousId === entry.id) showScene(sceneId);
      toast('場面を削除しました。', true);
    }) });
}

function manageScenes() {
  const body = dialog('場面の管理');
  const list = node('ol', '', 'scene-list');
  const move = (index, delta) => run(async () => {
    const ordered = [...dataset.scenes];
    [ordered[index], ordered[index + delta]] = [ordered[index + delta], ordered[index]];
    await changeScenes(ordered);
    manageScenes();
  });
  for (const [index, scene] of dataset.scenes.entries()) {
    const line = node('li');
    const name = (index + 1) + '. ' + scene.name + (scene.id === sceneId ? '（編集中）' : '');
    line.append(node('strong', name, 'scene-name'));
    const actions = node('div', '', 'row-actions');
    const open = button('開く', () => run(async () => { await flush(); closeDialog(); showScene(scene.id); }));
    open.disabled = scene.id === sceneId;
    const up = button('上へ', () => move(index, -1));
    const down = button('下へ', () => move(index, 1));
    up.disabled = index === 0;
    down.disabled = index === dataset.scenes.length - 1;
    const copy = button('複製', () => newSceneMenu(scene));
    const remove = button('削除', () => removeScene(scene), 'danger-text');
    remove.disabled = dataset.scenes.length <= 1;
    actions.append(open, button('名前変更', () => renameScene(scene)), up, down, copy, remove);
    line.append(actions);
    list.append(line);
  }
  body.append(list);
}

function renderPen() {
  const buttons = penColors.map((color, index) => {
    const item = button(colorNames[index], () => {
      pen.color = color;
      renderPen();
      $('pen-colors').children[index].focus();
      savePen();
    });
    item.textContent = '';
    item.setAttribute('aria-label', colorNames[index]);
    item.title = colorNames[index];
    item.setAttribute('aria-pressed', String(color === pen.color));
    const dot = node('span', '', 'dot');
    dot.style.setProperty('--swatch', color);
    item.append(dot);
    return item;
  });
  $('pen-colors').replaceChildren(...buttons);
  $('pen-width').value = String(pen.width);
}

function savePen() { void store.setSetting('pen', { ...pen }).catch(() => {}); }

function exportMenu() {
  showChoices('相関図を出力', [
    { label: '今の場面のみ（PDF）', action: () => pdfOutput(false) },
    { label: '全場面をまとめて（PDF）', action: () => pdfOutput(true) },
    { label: '作品をJSONで保存', action: () => jsonOutput(false) },
  ]);
}

function setOutput(body, blob, extension) {
  const group = node('div', '', 'export-result');
  releaseFile?.();
  releaseFile = attachFile(group, blob, dataset.work.title, extension);
  body.append(group);
}

function jsonOutput(emergency) {
  run(async () => {
    if (!emergency) await flush();
    const body = dialog('作品をJSONで保存');
    body.append(node('p', 'この作品の全場面が入ります。別の端末や公開先では、トップの「JSONファイルから読み込む」で続けられます。'));
    setOutput(body, jsonFile(dataset.work, dataset.scenes), 'json');
  });
}

function pdfOutput(all, lowResolution = false) {
  run(async () => {
    await flush();
    const body = dialog(all ? '全場面のPDF' : '今の場面のPDF');
    const status = node('p', 'PDFを準備しています…');
    status.setAttribute('role', 'status');
    body.append(status);
    $('close-modal').disabled = true;
    try {
      const blob = await makePdf(dataset.work, all ? dataset.scenes : [current()], {
        lowResolution, progress: (scene, total) => { status.textContent = scene + ' / ' + total + ' 場面を作成中'; },
      });
      status.textContent = 'PDFができました。ファイルに保存できます。';
      setOutput(body, blob, 'pdf');
    } catch {
      status.textContent = 'PDFを作成できませんでした。もう一度試すか、解像度を下げてください。';
      body.append(button('もう一度作る', () => pdfOutput(all, lowResolution)), document.createTextNode(' '),
        button('解像度を下げて作る', () => pdfOutput(all, true), 'primary'));
    } finally { $('close-modal').disabled = false; }
  });
}

function importWork() {
  showChoices('JSONファイルから読み込む', [
    { label: 'JSONファイルを選ぶ', action: () => $('import-file').click(), className: 'primary' },
  ], '保存した作品を別の作品として取りこみます。');
}

function libraryDestination() {
  const base = new URL('../../', location.href);
  try {
    const item = JSON.parse(sessionStorage.getItem('kyozai:portal:return') || 'null');
    const target = new URL(item?.url ?? '', base);
    if (target.origin === base.origin && [base.pathname, base.pathname + 'index.html'].includes(target.pathname)) return target.href;
  } catch { /* The library home is always available as a fallback. */ }
  return base.href;
}

function leaveForLibrary() {
  run(async () => {
    await flush();
    location.assign(libraryDestination());
  });
}

click('new-work', create);
click('list-new', create);
click('open-works', () => run(showWorks));
click('home-back', goHome);
click('editor-back', () => run(async () => { await flush(); await showWorks(); }));
click('next-scene', () => newSceneMenu());
click('scene-menu', manageScenes);
listen('scene-select', 'change', event => {
  const id = event.target.value;
  event.target.value = sceneId;
  run(async () => { await flush(); showScene(id); });
});
click('note-menu', () => showChoices('メモを追加', Object.entries(NOTE).map(([type, note]) => ({
  label: note.label, color: note.color, className: 'note-choice', action: () => editBox('note', undefined, type),
}))));
for (const element of document.querySelectorAll('button[data-mode]')) element.onclick = () => setMode(element.dataset.mode);
for (const element of document.querySelectorAll('[data-add]')) element.onclick = () => editBox(element.dataset.add);
click('edit-item', () => {
  const item = selectedItem();
  if (item?.type === 'relation') editRelation(item, item);
  else if (item && item.type !== 'stroke') editBox(item.type, item);
});
click('delete-item', removeItem);
click('undo', () => historyStep('undo'));
click('redo', () => historyStep('redo'));
click('zoom-out', () => board.zoom(-0.25));
click('zoom-in', () => board.zoom(0.25));
click('zoom-fit', board.fit);
click('export', exportMenu);
click('emergency-json', () => jsonOutput(true));
click('retry-save', () => run(() => autosave.retry()));
click('reopen', () => showForm({ title: '保存済みの作品を開き直す', message: 'このタブの未保存の編集を取り消します。残したい場合は先にJSONを保存してください。',
  confirm: '開き直す', danger: true, onSubmit: () => critical(async () => {
    const fresh = await store.read(dataset.work.id);
    if (fresh?.scenes.length) showEditor(fresh, fresh.scenes.some(scene => scene.id === sceneId) ? sceneId : fresh.scenes[0].id);
    else await showWorks();
  }) }));
listen('pen-width', 'change', event => { pen.width = Number(event.target.value); savePen(); });

click('import-json', importWork);
listen('import-file', 'change', event => {
  const file = event.target.files[0];
  event.target.value = '';
  if (!file) return;
  run(async () => {
    const body = dialog('JSONファイルから読み込む');
    const status = node('p', 'ファイルを確認しています…');
    status.setAttribute('role', 'status');
    body.append(status);
    $('close-modal').disabled = true;
    try {
      const next = await readBackup(file);
      await store.add(next.work, next.scenes);
      await showWorks();
      closeDialog();
      toast('「' + next.work.title + '」を新しい作品として読み込みました。');
    } catch (error) {
      status.textContent = error.message || 'JSONを読み込めませんでした。';
      body.append(button('別のファイルを選ぶ', () => $('import-file').click()));
    } finally { $('close-modal').disabled = false; }
  });
});
click('close-modal', closeDialog);
listen('modal', 'cancel', event => {
  if ($('close-modal').disabled) event.preventDefault();
});
listen('modal', 'close', () => {
  if ($('modal').open) return;
  releaseFile?.();
  releaseFile = undefined;
  $('modal-body').replaceChildren();
});
click('restore-deleted', () => run(async () => {
  if (!restoreAction) return;
  await restoreAction();
  restoreAction = undefined;
  toast('削除を取り消しました。');
}));
click('close-toast', () => { $('toast').hidden = true; restoreAction = undefined; });

document.addEventListener('keydown', event => {
  if ($('editor').hidden || $('modal').open || event.isComposing || ['INPUT', 'SELECT', 'TEXTAREA'].includes(event.target.tagName)) return;
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'z') {
    event.preventDefault();
    historyStep(event.shiftKey ? 'redo' : 'undo');
  } else if (event.key === 'Delete' && selectedItem()) {
    event.preventDefault();
    removeItem();
  } else if (event.key === 'Escape') setMode('select');
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') void flush().catch(() => {});
});
window.addEventListener('pagehide', () => { void flush().catch(() => {}); });
window.addEventListener('beforeunload', event => {
  if (!autosave?.dirty) return;
  event.preventDefault();
  event.returnValue = '';
});

if (inLibrary) {
  $('library-link').hidden = false;
  $('library-link').href = libraryDestination();
  $('editor-library').hidden = false;
  click('editor-library', leaveForLibrary);
}

async function start() {
  installToolIcons();
  const preview = $('home-example');
  const ctx = preview.getContext('2d');
  if (ctx) {
    ctx.scale(preview.width / PAGE.width, preview.height / PAGE.height);
    drawPaper(ctx, example.title, example.name, example.elements);
  }
  try {
    store = await openStore();
    // A successful open alone does not prove that the current browser allows writes.
    const setting = await store.getSetting('pen');
    if (penColors.includes(setting?.color)) pen.color = setting.color;
    if ([3, 7, 13].includes(setting?.width)) pen.width = setting.width;
    await store.setSetting('pen', { ...pen });
    renderPen();
    $('new-work').disabled = openButton.disabled = $('import-json').disabled = false;
    $('start-status').textContent = '作品はこのブラウザーに保存されます。';
  } catch {
    const status = $('start-status');
    status.textContent = '保存の準備ができませんでした。Safariで開き直してください。';
    status.append(document.createTextNode(' '), button('開き直す', () => location.reload(), 'small'));
  }
}
void start();
