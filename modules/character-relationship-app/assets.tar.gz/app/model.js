export const PAGE = { width: 1485, height: 1050 };
export const AREA = { left: 48, top: 134, right: 1437, bottom: 1002 };
export const BOX_MIN = { width: 120, height: 60 };
export const LIMIT = { scenes: 50, elements: 500, points: 100_000, bytes: 20 * 1024 * 1024 };
export const FORMAT = 'character-relationship-app';
export const NOTE = {
  feeling: { label: '心情メモ', color: '#FADBE7', ink: '#963453' },
  event: { label: '出来事メモ', color: '#D9EEFA', ink: '#205C83' },
  reason: { label: '理由メモ', color: '#F9EDB9', ink: '#71500E' },
  free: { label: '自由メモ', color: '#FFFFFF', ink: '#40584F' },
};
export const PALETTE = ['#DCEDE1', '#FADBE7', '#D9EEFA', '#F9EDB9', '#E7E0F8', '#FFFFFF'];
export const INKS = ['#262E31', '#B62946', '#205DB2', '#207454', '#8353B0'];
export const LINE_TYPES = {
  straight: { label: '直線', lineStyle: 'solid', arrowMode: 'none' },
  arrow: { label: '矢印', lineStyle: 'solid', arrowMode: 'end' },
  both: { label: '双方向矢印', lineStyle: 'solid', arrowMode: 'both' },
  dashed: { label: '点線', lineStyle: 'dashed', arrowMode: 'none' },
};

export const newId = () => crypto.randomUUID();
export const now = () => new Date().toISOString();
export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
export const ordered = scenes => [...scenes].sort((a, b) => a.order - b.order);
export const reindex = scenes => scenes.map((scene, order) => scene.order === order ? scene : { ...scene, order });

export function checkName(value, max, label) {
  const result = value.trim();
  if (!result || Array.from(result).length > max) {
    throw new Error(label + 'を1〜' + max + '文字で入れてください。');
  }
  return result;
}

export function newScene(workId, name, order, elements = [], date = now()) {
  return { id: newId(), workId, name, order, createdAt: date, updatedAt: date, elements };
}

export function createWork(title, name) {
  const date = now();
  const work = { id: newId(), title, createdAt: date, updatedAt: date, revision: 0 };
  return { work, scenes: [newScene(work.id, name, 0, [], date)] };
}

export function duplicateElements(elements) {
  const ids = new Map(elements.map(element => [element.id, newId()]));
  return elements.map(element => {
    const copy = structuredClone(element);
    copy.id = ids.get(element.id);
    if (copy.type === 'relation') {
      copy.sourceId = ids.get(element.sourceId);
      copy.targetId = ids.get(element.targetId);
    }
    return copy;
  });
}

export function duplicateWork({ work, scenes }, title, keepDates = false) {
  const id = newId();
  const date = now();
  return {
    work: { id, title, createdAt: keepDates ? work.createdAt : date, updatedAt: date, revision: 0 },
    scenes: reindex(ordered(scenes)).map(scene => ({
      ...scene, id: newId(), workId: id, createdAt: keepDates ? scene.createdAt : date,
      updatedAt: keepDates ? scene.updatedAt : date, elements: duplicateElements(scene.elements),
    })),
  };
}

export function deleteElement(elements, id) {
  return elements.filter(element => element.id !== id &&
    !(element.type === 'relation' && (element.sourceId === id || element.targetId === id)));
}

export function replaceElement(elements, element) {
  return elements.map(previous => previous.id === element.id ? element : previous);
}

export function isBox(item) {
  return item?.type === 'person' || item?.type === 'note' || item?.type === 'text';
}

export function placeBox(box) {
  const width = clamp(box.width, BOX_MIN.width, AREA.right - AREA.left);
  const height = clamp(box.height, BOX_MIN.height, AREA.bottom - AREA.top);
  return {
    ...box, width, height, x: clamp(box.x, AREA.left, AREA.right - width),
    y: clamp(box.y, AREA.top, AREA.bottom - height),
  };
}

export function resizeBox(box, dx, dy) {
  return { ...box,
    width: clamp(box.width + Math.round(dx), BOX_MIN.width, AREA.right - box.x),
    height: clamp(box.height + Math.round(dy), BOX_MIN.height, AREA.bottom - box.y),
  };
}

export function backupObject(work, scenes, exportedAt = now()) {
  return { format: FORMAT, version: 1, exportedAt, work, scenes: ordered(scenes) };
}

const encoder = new TextEncoder();
const sceneBytes = new WeakMap();
function size(value) {
  return encoder.encode(JSON.stringify(value)).length;
}

export function checkLimits(work, scenes) {
  if (scenes.length < 1 || scenes.length > LIMIT.scenes) {
    throw new Error('1つの作品には1〜' + LIMIT.scenes + '場面を入れられます。');
  }
  // Compute the same UTF-8 byte count used by the compact export, reusing unchanged scenes.
  let bytes = size(backupObject(work, [])) + scenes.length - 1;
  for (const scene of scenes) {
    if (scene.elements.length > LIMIT.elements) {
      throw new Error('1つの場面に置けるのは' + LIMIT.elements + '個までです。');
    }
    const points = scene.elements.reduce((total, element) => total + (element.points?.length ?? 0), 0);
    if (points > LIMIT.points) throw new Error('この場面は手書きの量が上限に達しました。');
    if (!sceneBytes.has(scene)) sceneBytes.set(scene, size(scene));
    bytes += sceneBytes.get(scene);
  }
  // Reserve space for later revision numbers and keep the work exportable.
  if (bytes + 16 > LIMIT.bytes) throw new Error('作品の容量が20 MiBの上限に達しました。');
}

export function safeFileName(title, extension) {
  const clean = title.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/u, '').trim() || '作品';
  const date = new Date();
  const stamp = [date.getFullYear(), date.getMonth() + 1, date.getDate()]
    .map(value => String(value).padStart(2, '0')).join('');
  return '人物相関図_' + clean + '_' + stamp + '.' + extension;
}
