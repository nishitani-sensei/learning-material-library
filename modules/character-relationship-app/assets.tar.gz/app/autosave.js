export class Autosave {
  #number = 0;
  #saved = 0;
  #timer;
  #pending;
  #inFlight;
  #error;
  #save;
  #notify;
  #delay;

  constructor(save, notify, delay = 800) {
    this.#save = save;
    this.#notify = notify;
    this.#delay = delay;
  }

  get dirty() { return this.#number !== this.#saved; }

  #status(status, error) {
    this.#notify(status, error);
  }

  change(payload) {
    this.#number++;
    this.#pending = payload;
    if (this.#error) return;
    this.#status('dirty');
    clearTimeout(this.#timer);
    this.#timer = setTimeout(() => { void this.flush().catch(() => {}); }, this.#delay);
  }

  async flush() {
    clearTimeout(this.#timer);
    if (this.#error) throw this.#error;
    if (this.#inFlight) {
      await this.#inFlight;
      if (this.dirty) return this.flush();
      return;
    }
    if (!this.dirty) return;
    const number = this.#number;
    const payload = this.#pending;
    this.#status('saving');
    const operation = Promise.resolve().then(() => this.#save(payload)).then(() => {
      this.#saved = number;
      this.#status(this.dirty ? 'dirty' : 'saved');
    }).catch(error => {
      this.#error = error;
      this.#status('error', error);
      throw error;
    }).finally(() => {
      this.#inFlight = null;
    });
    this.#inFlight = operation;
    await operation;
  }

  retry() {
    this.#error = null;
    return this.flush();
  }

  block(error) {
    clearTimeout(this.#timer);
    this.#error = error;
    this.#status('error', error);
  }

  dispose() { clearTimeout(this.#timer); }
}
