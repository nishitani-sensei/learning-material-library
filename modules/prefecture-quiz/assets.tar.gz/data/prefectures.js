const rows = [
  ['北海道', 'ほっかいどう', '札幌市', 'さっぽろし'],
  ['青森県', 'あおもりけん', '青森市', 'あおもりし'],
  ['岩手県', 'いわてけん', '盛岡市', 'もりおかし'],
  ['宮城県', 'みやぎけん', '仙台市', 'せんだいし'],
  ['秋田県', 'あきたけん', '秋田市', 'あきたし'],
  ['山形県', 'やまがたけん', '山形市', 'やまがたし'],
  ['福島県', 'ふくしまけん', '福島市', 'ふくしまし'],
  ['茨城県', 'いばらきけん', '水戸市', 'みとし'],
  ['栃木県', 'とちぎけん', '宇都宮市', 'うつのみやし'],
  ['群馬県', 'ぐんまけん', '前橋市', 'まえばしし'],
  ['埼玉県', 'さいたまけん', 'さいたま市', 'さいたまし'],
  ['千葉県', 'ちばけん', '千葉市', 'ちばし'],
  ['東京都', 'とうきょうと', '東京', 'とうきょう'],
  ['神奈川県', 'かながわけん', '横浜市', 'よこはまし'],
  ['新潟県', 'にいがたけん', '新潟市', 'にいがたし'],
  ['富山県', 'とやまけん', '富山市', 'とやまし'],
  ['石川県', 'いしかわけん', '金沢市', 'かなざわし'],
  ['福井県', 'ふくいけん', '福井市', 'ふくいし'],
  ['山梨県', 'やまなしけん', '甲府市', 'こうふし'],
  ['長野県', 'ながのけん', '長野市', 'ながのし'],
  ['岐阜県', 'ぎふけん', '岐阜市', 'ぎふし'],
  ['静岡県', 'しずおかけん', '静岡市', 'しずおかし'],
  ['愛知県', 'あいちけん', '名古屋市', 'なごやし'],
  ['三重県', 'みえけん', '津市', 'つし'],
  ['滋賀県', 'しがけん', '大津市', 'おおつし'],
  ['京都府', 'きょうとふ', '京都市', 'きょうとし'],
  ['大阪府', 'おおさかふ', '大阪市', 'おおさかし'],
  ['兵庫県', 'ひょうごけん', '神戸市', 'こうべし'],
  ['奈良県', 'ならけん', '奈良市', 'ならし'],
  ['和歌山県', 'わかやまけん', '和歌山市', 'わかやまし'],
  ['鳥取県', 'とっとりけん', '鳥取市', 'とっとりし'],
  ['島根県', 'しまねけん', '松江市', 'まつえし'],
  ['岡山県', 'おかやまけん', '岡山市', 'おかやまし'],
  ['広島県', 'ひろしまけん', '広島市', 'ひろしまし'],
  ['山口県', 'やまぐちけん', '山口市', 'やまぐちし'],
  ['徳島県', 'とくしまけん', '徳島市', 'とくしまし'],
  ['香川県', 'かがわけん', '高松市', 'たかまつし'],
  ['愛媛県', 'えひめけん', '松山市', 'まつやまし'],
  ['高知県', 'こうちけん', '高知市', 'こうちし'],
  ['福岡県', 'ふくおかけん', '福岡市', 'ふくおかし'],
  ['佐賀県', 'さがけん', '佐賀市', 'さがし'],
  ['長崎県', 'ながさきけん', '長崎市', 'ながさきし'],
  ['熊本県', 'くまもとけん', '熊本市', 'くまもとし'],
  ['大分県', 'おおいたけん', '大分市', 'おおいたし'],
  ['宮崎県', 'みやざきけん', '宮崎市', 'みやざきし'],
  ['鹿児島県', 'かごしまけん', '鹿児島市', 'かごしまし'],
  ['沖縄県', 'おきなわけん', '那覇市', 'なはし'],
];

export const regions = [
  { id: 'hokkaido', name: '北海道', reading: 'ほっかいどう', color: '#b88ac4', first: 1, last: 1 },
  { id: 'tohoku', name: '東北', reading: 'とうほく', color: '#869be0', first: 2, last: 7 },
  { id: 'kanto', name: '関東', reading: 'かんとう', color: '#f1ce50', first: 8, last: 14 },
  { id: 'chubu', name: '中部', reading: 'ちゅうぶ', color: '#6bc3a1', first: 15, last: 23 },
  { id: 'kinki', name: '近畿', reading: 'きんき', color: '#ef9f60', first: 24, last: 30 },
  { id: 'chugoku', name: '中国', reading: 'ちゅうごく', color: '#66bbd4', first: 31, last: 35 },
  { id: 'shikoku', name: '四国', reading: 'しこく', color: '#eea8c0', first: 36, last: 39 },
  { id: 'kyushu', name: '九州・沖縄', reading: 'きゅうしゅう・おきなわ', color: '#e87d70', first: 40, last: 47 },
];

export const north = { id: 'north', name: '北海道・東北', reading: 'ほっかいどう・とうほく', first: 1, last: 7 };
export const localRanges = [north, ...regions.slice(2)];
export const national = { id: 'all', name: '全国', reading: 'ぜんこく', first: 1, last: 47 };
export const ranges = [national, ...localRanges];
export const rangeById = Object.fromEntries(ranges.map(range => [range.id, range]));

export const prefectures = rows.map(([name, reading, capital, capitalReading], index) => {
  const number = index + 1;
  const region = regions.find(region => number >= region.first && number <= region.last);
  return { id: String(number).padStart(2, '0'), number, name, reading, capital, capitalReading, region };
});
export const prefectureById = Object.fromEntries(prefectures.map(pref => [pref.id, pref]));
export const inRange = (pref, range) => pref.number >= range.first && pref.number <= range.last;
export const practiceRange = pref => localRanges.find(range => inRange(pref, range));

export const capitalSource = 'https://www.nga.gr.jp/pref_info/item/pdf/20230302_Prefectural_Office.pdf';
export const tokyoSource = 'https://www.seisakukikaku.metro.tokyo.lg.jp/about/syozaichi';
