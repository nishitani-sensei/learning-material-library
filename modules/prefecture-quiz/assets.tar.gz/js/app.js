import { prefectureById, practiceRange, national, rangeById, regions } from '../data/prefectures.js';
import { createRun, nextQuestion, submitAnswer, resumeClock, pauseClock, elapsed, formatTime } from './quiz.js';
import { createRecords } from './storage.js';
import { constrainView, defaultView, islandAreas, zoomView } from './maps.js';
import * as views from './views.js';

const app = document.getElementById('app');
const dialog = document.getElementById('confirm-dialog');
const rubyToggle = document.getElementById('ruby-toggle');
const records = createRecords();
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
let screen = 'home';
let type = 'location';
let range = national;
let run = null;
let currentProgress;
let lastTimeResult = null;
let result = null;
let atlas = null;
let waiting = false;
let animationFrame = null;
let timerInterval = null;
let dialogAction = null;
let drag = null;
let skipMapClick = false;

function setRuby() {
  const on = records.ruby();
  document.body.dataset.ruby = on ? 'on' : 'off';
  rubyToggle.setAttribute('aria-pressed', String(on));
}

function storageNotice() {
  return records.available ? '' : '<p class="storage-notice" role="status">このブラウザでは記録を保存できません。ページを開いている間は続けて遊べます。</p>';
}

const screens = {
  home: () => views.home(records.progress()),
  modes: () => views.modes(type, records.best(type)),
  ranges: () => views.rangePicker(type),
  approach: () => views.approachPicker(records.progress(), type, range),
  'time-setup': () => views.timeSetup(type, records.best(type)),
  question: achievements => views.questionScreen(run, achievements),
  result: () => views.resultScreen(result),
  review: () => views.reviewScreen(lastTimeResult),
  atlas: () => views.atlasScreen(records.progress(), atlas, false),
  master: () => views.atlasScreen(records.progress(), atlas, true),
  sources: views.sourcesScreen,
  settings: views.settingsScreen,
};

function render(next, { resetScroll = true, focus = true, achievements = [] } = {}) {
  screen = next;
  app.innerHTML = screens[next](achievements) + storageNotice();
  if (resetScroll) window.scrollTo(0, 0);
  if (focus) app.querySelector('h1')?.focus({ preventScroll: true });
}

function tick() {
  const clock = document.getElementById('timer');
  if (clock && run) clock.textContent = formatTime(elapsed(run));
}

function cancelFrame() {
  if (animationFrame !== null) cancelAnimationFrame(animationFrame);
  animationFrame = null;
}

function stopClock() {
  cancelFrame();
  window.clearInterval(timerInterval);
  timerInterval = null;
  if (run) pauseClock(run);
  if (screen === 'question' && run && !run.response) {
    waiting = true;
    for (const element of app.querySelectorAll('button[data-action="answer"]')) element.disabled = true;
  }
  tick();
}

function armAnswers() {
  cancelFrame();
  if (!run || run.response || dialog.open || document.visibilityState !== 'visible') return;
  const question = run.question;
  animationFrame = requestAnimationFrame(() => {
    animationFrame = requestAnimationFrame(() => {
      animationFrame = null;
      if (run?.question !== question || run.response || dialog.open || document.visibilityState !== 'visible') return;
      waiting = false;
      for (const element of app.querySelectorAll('button[data-action="answer"]')) element.disabled = false;
      resumeClock(run);
      tick();
      if (run.mode === 'time' && timerInterval === null) timerInterval = window.setInterval(tick, 40);
    });
  });
}

function celebrate() {
  if (reducedMotion.matches) return;
  const overlay = document.createElement('div');
  overlay.className = 'celebration';
  overlay.setAttribute('aria-hidden', 'true');
  const colors = ['#e6a027', '#4a9b6d', '#d0646b', '#639bc0'];
  for (let index = 0; index < 26; index++) {
    const piece = document.createElement('i');
    const side = index < 13 ? 1 : -1;
    piece.style.setProperty('--left', (side > 0 ? 13 : 85) + index % 5 + '%');
    piece.style.setProperty('--spread', side * (5 + index % 8 * 2) + 'vw');
    piece.style.setProperty('--drift', side * (15 + index % 11) + 'vw');
    piece.style.setProperty('--color', colors[index % colors.length]);
    piece.style.setProperty('--delay', index % 6 * 38 + 'ms');
    overlay.append(piece);
  }
  app.append(overlay);
  window.setTimeout(() => overlay.remove(), 2400);
}

function showQuestion() {
  stopClock();
  currentProgress = records.progress();
  const question = nextQuestion(run);
  if (!question) return;
  records.shown(question.prefecture, run.type);
  waiting = true;
  render('question');
  armAnswers();
}

function start(value, first = null) {
  stopClock();
  const timed = value === 'time';
  const reviewing = value === 'review';
  if (reviewing && !lastTimeResult?.mistakes.size) return;
  if (reviewing) type = lastTimeResult.type;
  run = createRun({
    type, mode: timed ? 'time' : reviewing ? 'review' : 'endless',
    range: timed || reviewing ? national : range,
    approach: value === 'master' ? 'master' : 'normal', first,
    achieved: (id, kind) => (currentProgress.history[id]?.[kind]?.correct ?? 0) > 0,
    review: reviewing ? [...lastTimeResult.mistakes.values()].map(mistake => mistake.question) : [],
  });
  showQuestion();
}

function answer(id) {
  if (screen !== 'question' || !run || waiting || dialog.open || document.visibilityState !== 'visible') return;
  const response = submitAnswer(run, id);
  if (!response) return;
  stopClock();
  const achievements = records.answer(run.question.prefecture, run.type, response.correct);
  if (run.complete && run.mode === 'time') {
    run.ms = elapsed(run);
    run.record = records.saveBest(run.type, run.ms);
  }
  render('question', { resetScroll: false, focus: false, achievements });
  const feedback = document.getElementById('feedback');
  feedback?.focus({ preventScroll: true });
  if (feedback?.getBoundingClientRect().top > window.innerHeight - 95) {
    feedback.scrollIntoView({ block: 'nearest' });
  }
  if (achievements.length) celebrate();
}

function next() {
  if (!run?.response) return;
  if (!run.complete) {
    showQuestion();
    return;
  }
  stopClock();
  result = run;
  if (run.mode === 'time') lastTimeResult = result;
  run = null;
  render('result');
  if (result.record?.improved) celebrate();
}

function confirm(title, message, label, action) {
  if (dialog.open) return;
  stopClock();
  dialogAction = action;
  dialog.returnValue = 'cancel';
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-message').textContent = message;
  document.getElementById('confirm-accept').textContent = label;
  dialog.showModal();
}

function enterAtlas(name) {
  atlas = { area: 'all', zoom: 1, view: defaultView('all'), pref: null };
  render(name);
}

function go(destination) {
  const here = screen;
  const navigate = () => {
    stopClock();
    run = null;
    if (destination === 'master' || destination === 'atlas') enterAtlas(destination);
    else render(destination);
  };
  if (here === 'question' && run && !run.complete) {
    const message = run.mode === 'time' ? '30問正解したときのタイムが、最高記録の対象になります。' : '答えた問題の学習記録は残ります。';
    confirm('クイズを終わりますか？', message, 'クイズを終わる', navigate);
  } else navigate();
}

function setArea(value, scroll = false) {
  const allowed = ['all', ...regions.map(region => region.id), ...islandAreas];
  if (!atlas || !allowed.includes(value)) return;
  atlas.area = value;
  atlas.zoom = 1;
  atlas.view = defaultView(value);
  render(screen, { resetScroll: false, focus: false });
  const control = document.getElementById('area');
  control?.focus({ preventScroll: true });
  if (scroll) control?.scrollIntoView({ block: 'nearest' });
}

function updateAtlasMap() {
  app.querySelector('.atlas-map').innerHTML = views.atlasMap(records.progress(), atlas, screen === 'master');
}

function selectPref(value) {
  if (!atlas || !prefectureById[value]) return;
  atlas.pref = value;
  const master = screen === 'master';
  updateAtlasMap();
  for (const control of app.querySelectorAll('#pref-groups button')) {
    control.setAttribute('aria-pressed', String(control.dataset.value === value));
  }
  const panel = document.getElementById('pref-details');
  panel.innerHTML = views.atlasDetails(records.progress(), atlas, master);
  document.getElementById('pref-title')?.focus({ preventScroll: true });
  if (panel.getBoundingClientRect().top > window.innerHeight - 95) panel.scrollIntoView({ block: 'start' });
}

function zoom(direction) {
  if (!atlas) return;
  const factor = Math.min(4, Math.max(1, atlas.zoom * (direction === 'in' ? 2 : .5)));
  if (factor === atlas.zoom) return;
  atlas.view = factor === 1 ? defaultView(atlas.area) : zoomView(atlas.area, factor, atlas.view, atlas.pref);
  atlas.zoom = factor;
  updateAtlasMap();
  const expand = app.querySelector('button[data-value="in"]');
  const shrink = app.querySelector('button[data-value="out"]');
  expand.disabled = factor >= 4;
  shrink.disabled = factor <= 1;
  (direction === 'in' && !expand.disabled || shrink.disabled ? expand : shrink).focus({ preventScroll: true });
}

function reset(which) {
  if (which === 'best') {
    confirm('最高タイムをリセットしますか？', '3種類の最高タイムが消えます。', 'リセットする', () => {
      records.resetBest();
      lastTimeResult = null;
      render('settings');
    });
  } else {
    confirm('マスター・学習記録をリセットしますか？', '今までのマスターと正解・不正解の記録が消えます。', 'リセットする', () => {
      records.resetProgress();
      render('settings');
    });
  }
}

const actions = {
  home: () => go('home'),
  master: () => go('master'),
  atlas: () => go('atlas'),
  settings: () => go('settings'),
  sources: () => go('sources'),
  ruby: () => { records.setRuby(!records.ruby()); setRuby(); },
  type: value => { type = value; render('modes'); },
  modes: () => render('modes'),
  ranges: () => render('ranges'),
  range: value => { range = rangeById[value]; render('approach'); },
  'time-setup': () => render('time-setup'),
  start,
  answer,
  next,
  review: () => render('review'),
  'time-result': () => { result = lastTimeResult; render('result'); },
  reset,
  area: value => setArea(value, true),
  zoom,
  pref: selectPref,
  'focus-map': value => setArea(prefectureById[value].region.id, true),
  'focus-practice': value => {
    const pref = prefectureById[atlas.pref];
    type = value;
    range = practiceRange(pref);
    start('master', pref);
  },
};

document.addEventListener('click', event => {
  const control = event.target.closest('[data-action]');
  if (!control || control.disabled || (skipMapClick && control.closest('.geo-map'))) return;
  if (control.tagName === 'A' && (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey)) return;
  event.preventDefault();
  const { action, value } = control.dataset;
  actions[action]?.(value);
});

app.addEventListener('change', event => {
  if (event.target.id === 'area') setArea(event.target.value);
});

app.addEventListener('toggle', event => {
  const entry = event.target;
  if (!entry.open || !entry.dataset.question || !lastTimeResult) return;
  const content = entry.querySelector('.review-content');
  if (!content.childElementCount) content.innerHTML = views.reviewEntry(lastTimeResult.mistakes.get(entry.dataset.question));
}, true);

dialog.addEventListener('close', () => {
  const action = dialogAction;
  dialogAction = null;
  if (dialog.returnValue === 'confirm') action?.();
  else if (screen === 'question') armAnswers();
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') stopClock();
  else if (screen === 'question') armAnswers();
});
window.addEventListener('pagehide', stopClock);
window.addEventListener('pageshow', () => { if (screen === 'question') armAnswers(); });

app.addEventListener('pointerdown', event => {
  const svg = event.target.closest('.geo-map.can-pan');
  if (!svg || !event.isPrimary) return;
  const scale = svg.getScreenCTM()?.a;
  if (!scale) return;
  drag = { svg, scale, pointerId: event.pointerId, x: event.clientX, y: event.clientY, start: [...atlas.view], moved: false };
});

app.addEventListener('pointermove', event => {
  if (!drag || event.pointerId !== drag.pointerId) return;
  const dx = event.clientX - drag.x;
  const dy = event.clientY - drag.y;
  if (!drag.moved && Math.hypot(dx, dy) < 6) return;
  if (!drag.moved) drag.svg.setPointerCapture(event.pointerId);
  drag.moved = true;
  const [x, y, width, height] = drag.start;
  atlas.view = constrainView(atlas.area, [x - dx / drag.scale, y - dy / drag.scale, width, height]);
  drag.svg.setAttribute('viewBox', atlas.view.join(' '));
  const clip = drag.svg.querySelector('clipPath rect');
  if (clip) {
    clip.setAttribute('x', atlas.view[0]);
    clip.setAttribute('y', atlas.view[1]);
  }
});

function endDrag(event) {
  if (!drag || event.pointerId !== drag.pointerId) return;
  skipMapClick = drag.moved;
  drag = null;
  window.setTimeout(() => { skipMapClick = false; }, 60);
}
window.addEventListener('pointerup', endDrag);
window.addEventListener('pointercancel', endDrag);

setRuby();
render('home', { focus: false });
