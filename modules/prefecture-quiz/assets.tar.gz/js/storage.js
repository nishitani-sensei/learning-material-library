import { prefectures, localRanges, inRange, practiceRange } from '../data/prefectures.js';
import { typeIds } from './quiz.js';

const prefix = 'prefecture-quiz:v1:';
const integer = value => Number.isSafeInteger(value) && value >= 0 ? value : 0;
const hasMastered = entries => typeIds.every(type => entries?.[type]?.correct > 0);

export function createRecords(getStorage = () => window.localStorage) {
  const pending = new Map();
  let available = true;

  function read(key) {
    if (pending.has(key)) return pending.get(key);
    try {
      return JSON.parse(getStorage().getItem(prefix + key));
    } catch (error) {
      if (!(error instanceof SyntaxError)) available = false;
      return null;
    }
  }

  function save(key, value) {
    try {
      getStorage().setItem(prefix + key, JSON.stringify(value));
      pending.delete(key);
      available = true;
    } catch {
      pending.set(key, value);
      available = false;
    }
  }

  function progress() {
    const value = read('progress');
    const history = {};
    for (const pref of prefectures) {
      const entries = value?.history?.[pref.id];
      if (!entries) continue;
      history[pref.id] = Object.fromEntries(typeIds.map(type => {
        const current = entries[type];
        return [type, {
          shown: integer(current?.shown), correct: integer(current?.correct), incorrect: integer(current?.incorrect),
        }];
      }));
    }
    return { version: 1, history, celebrated: Array.isArray(value?.celebrated) ? value.celebrated : [] };
  }

  function update(pref, type, field) {
    const state = progress();
    const entries = state.history[pref.id] ??= {};
    const item = entries[type] ??= { shown: 0, correct: 0, incorrect: 0 };
    item[field]++;
    const unlocked = [];
    if (field === 'correct' && hasMastered(entries)) {
      const range = practiceRange(pref);
      const allThere = prefectures.filter(item => inRange(item, range))
        .every(item => hasMastered(state.history[item.id]));
      const allJapan = prefectures.every(item => hasMastered(state.history[item.id]));
      const milestones = [
        [pref.id, pref.name + 'マスター！', true],
        [range.id, range.name + 'マスター！', allThere],
        ['all', '47都道府県 完全制覇！', allJapan],
      ];
      for (const [key, label, reached] of milestones) {
        if (reached && !state.celebrated.includes(key)) {
          state.celebrated.push(key);
          unlocked.push(label);
        }
      }
    }
    save('progress', state);
    return unlocked;
  }

  function best(type) {
    const value = read('best:' + type)?.ms;
    return Number.isFinite(value) && value >= 0 ? value : null;
  }

  return {
    progress,
    achieved(id, type) { return (progress().history[id]?.[type]?.correct ?? 0) > 0; },
    shown(pref, type) { update(pref, type, 'shown'); },
    answer(pref, type, correct) { return update(pref, type, correct ? 'correct' : 'incorrect'); },
    best,
    saveBest(type, ms) {
      const previous = best(type);
      const improved = previous === null || ms < previous;
      if (improved) save('best:' + type, { version: 1, ms });
      return { best: improved ? ms : previous, improved, first: previous === null };
    },
    get available() { return available; },
    ruby() { return read('settings')?.ruby !== false; },
    setRuby(ruby) { save('settings', { version: 1, ruby }); },
    resetProgress() { save('progress', { version: 1, history: {}, celebrated: [] }); },
    resetBest() { for (const type of typeIds) save('best:' + type, { version: 1, ms: null }); },
  };
}

export function status(state, id) {
  const entries = state.history[id];
  if (hasMastered(entries)) return 'mastered';
  return typeIds.some(type => entries?.[type]?.correct || entries?.[type]?.incorrect) ? 'learning' : 'new';
}

export function summary(state, range) {
  const pool = range ? prefectures.filter(pref => inRange(pref, range)) : prefectures;
  const mastered = pool.filter(pref => status(state, pref.id) === 'mastered').length;
  return { mastered, total: pool.length, remaining: pool.length - mastered };
}

export function byRegion(state) {
  return localRanges.map(range => ({ range, ...summary(state, range) }));
}
