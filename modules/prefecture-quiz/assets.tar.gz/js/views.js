import {
  prefectures, prefectureById, regions, ranges, rangeById, inRange, practiceRange,
  capitalSource, tokyoSource,
} from '../data/prefectures.js';
import { attractions } from '../data/attractions.js';
import { types, typeIds, target, elapsed, formatTime } from './quiz.js';
import { status, summary, byRegion } from './storage.js';
import { mapFrame, mapForQuestion, islandAreas, areaLabel, statusStyles, mapSource, officeSource, lakeSource } from './maps.js';

export const e = value => String(value).replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
})[char]);

export const ruby = (name, reading) => reading && reading !== name
  ? '<ruby>' + e(name) + '<rp>（</rp><rt>' + e(reading) + '</rt><rp>）</rp></ruby>' : e(name);

const icons = {
  pin: '<path d="M19 10c0 5-7 10-7 10S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.4"/>',
  flag: '<path d="M5 21V4m0 1c5-4 9 4 14 0v10c-5 4-9-4-14 0"/>',
  spark: '<path d="M12 3c.8 5 2.5 6.8 7.5 7.5-5 .8-6.7 2.5-7.5 7.5-.8-5-2.5-6.7-7.5-7.5C9.5 9.8 11.2 8 12 3Zm7 12v5m-2.5-2.5h5"/>',
  clock: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/>',
  repeat: '<path d="M20 11a8 8 0 1 0-2 5m2-10v5h-5"/>',
};

function icon(name) {
  return '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + icons[name] + '</svg>';
}

export function button(label, action, value = '', { style = '', attributes = '' } = {}) {
  return '<button type="button" class="button ' + style + '" data-action="' + action + '" data-value="' + e(value) + '" ' + attributes + '>' + label + '</button>';
}

function tile(label, description, action, value, symbol, tone = '') {
  return '<button type="button" class="tile" data-action="' + action + '" data-value="' + value + '" data-tone="' + tone + '"><span class="icon-box">'
    + icon(symbol) + '</span><span><strong>' + label + '</strong><small>' + description + '</small></span></button>';
}

function heading(title, back = 'home', backLabel = 'トップへ', kicker = '') {
  return '<div class="page-head"><div class="stack compact">' + (kicker ? '<p class="kicker">' + kicker + '</p>' : '')
    + '<h1 tabindex="-1">' + title + '</h1></div>' + button(backLabel, back) + '</div>';
}

export function meter(mastered, total) {
  return '<div class="meter" role="progressbar" aria-label="都道府県のマスター達成数" aria-valuemin="0" aria-valuemax="' + total + '" aria-valuenow="'
    + mastered + '"><span style="--progress:' + (mastered / total * 100) + '%"></span></div>';
}

const remainingText = remaining => remaining ? '全国制覇まであと' + remaining + '県！' : '47都道府県 完全制覇！';
const kindName = type => ruby(types[type].name, types[type].reading);
const bestTimeText = time => time === null ? 'まだ記録がありません' : formatTime(time);

export function home(state) {
  const { mastered, total, remaining } = summary(state);
  return '<div class="stack"><section class="home-hero"><div class="hero-text stack compact"><h1 tabindex="-1">47都道府県マスター</h1>'
    + '<p class="progress-number"><strong>' + mastered + '</strong><span>/ ' + total + ' 都道府県</span></p>' + meter(mastered, total)
    + '<p><strong>' + remainingText(remaining) + '</strong></p>' + button('マスター状況を見る', 'master', '', { style: 'primary' })
    + '</div><img class="hero-art" src="./assets/hero.svg" alt="" width="620" height="324"></section>'
    + '<section class="stack" aria-label="クイズを選ぶ"><div class="menus">'
    + typeIds.map(type => tile(kindName(type), types[type].note, 'type', type, types[type].icon, type)).join('')
    + '</div><div>' + button(ruby('都道府県一覧', 'とどうふけんいちらん'), 'atlas') + '</div></section></div>';
}

export function modes(type, best) {
  return '<div class="stack">' + heading(kindName(type)) + '<div class="mode-options">'
    + tile('エンドレス', '好きな地方を選んで、何問でも練習できます。', 'ranges', '', 'repeat')
    + tile('タイムアタック', '全国の問題で30問正解を目指します。', 'time-setup', '', 'clock', 'capital')
    + '</div><section class="panel stack compact"><h2>最高タイム</h2><p class="' + (best === null ? 'muted' : 'time-value') + '">' + bestTimeText(best)
    + '</p></section></div>';
}

export function rangePicker(type) {
  return '<div class="stack">' + heading('出題する地方を選ぼう', 'modes', 'モード選びへ', kindName(type) + ' ・ エンドレス')
    + '<div class="region-grid">' + ranges.map(range => button(ruby(range.name, range.reading), 'range', range.id,
      { style: 'region-button' + (range.id === 'all' ? ' primary' : '') })).join('') + '</div></div>';
}

export function approachPicker(state, type, range) {
  const { mastered, total } = summary(state, range);
  const incomplete = prefectures.filter(pref => inRange(pref, range) && !state.history[pref.id]?.[type]?.correct).length;
  return '<div class="stack">' + heading('練習のしかたを選ぼう', 'ranges', '地方選びへ', kindName(type) + ' ・ ' + range.name)
    + '<section class="panel stack compact"><p><strong>' + range.name + '　' + mastered + ' / ' + total + ' マスター</strong></p>'
    + meter(mastered, total) + '<p class="muted">' + types[type].short + 'が未達成の都道府県は' + incomplete + 'です。</p></section>'
    + '<div class="mode-options">' + tile('ふつうに練習', '範囲の都道府県を一巡します。', 'start', 'normal', 'repeat')
    + tile('マスターを目指す', '今選んだ項目が未達成の問題を多めに出します。', 'start', 'master', 'spark', 'charm')
    + '</div></div>';
}

export function timeSetup(type, best) {
  return '<div class="stack">' + heading('30問正解にチャレンジ！', 'modes', 'モード選びへ', kindName(type) + ' ・ タイムアタック')
    + '<section class="panel stack reading-block"><p>全国から出題します。4択に答えられる時間だけを計ります。解説はゆっくり読んで大丈夫です。</p>'
    + '<p><strong>最高タイム</strong>　' + bestTimeText(best) + '</p><div>' + button('スタート', 'start', 'time', { style: 'primary' }) + '</div></section></div>';
}

export function questionText(question) {
  const pref = question.prefecture;
  if (question.type === 'location') return '色がついている都道府県はどこ？';
  if (question.type === 'capital') {
    if (pref.id === '13') return '東京都の都庁所在地は、地図帳ではふつう何と書く？';
    return ruby(pref.name, pref.reading) + 'の' + ruby('県庁所在地', 'けんちょうしょざいち') + 'はどこ？';
  }
  const item = question.attraction;
  return e(item.clue) + ruby(item.name, item.reading) + 'で知られる都道府県はどこ？';
}

function details(pref, attraction, sources = false) {
  const items = attraction ? [attraction] : attractions[pref.id];
  const clarify = pref.id === '13' ? '<p class="small muted">教材では「東京」と表します。都庁があるのは新宿区西新宿です。</p>' : '';
  return '<dl class="fact-box"><div><dt>地方</dt><dd>' + ruby(pref.region.name, pref.region.reading) + '</dd></div>'
    + '<div><dt>都道府県</dt><dd>' + ruby(pref.name, pref.reading) + '</dd></div>'
    + '<div><dt>県庁所在地</dt><dd>' + ruby(pref.capital, pref.capitalReading) + '</dd></div></dl>' + clarify
    + items.map(item => '<div class="attraction"><h3>' + ruby(item.name, item.reading) + ' <span class="badge">'
      + e(item.category) + '</span></h3><p>' + e(item.description) + '</p>'
      + (sources ? '<a class="source-link" href="' + e(item.source) + '" target="_blank" rel="noopener noreferrer">日本政府観光局の資料（英語）</a>' : '')
      + '</div>').join('');
}

export function questionScreen(run, achievements = []) {
  const { question, response } = run;
  const pref = question.prefecture;
  const timed = run.mode === 'time';
  const practicing = run.mode === 'review';
  const isCharm = question.type === 'charm';
  const showMap = !isCharm || Boolean(response);
  const scoreboard = '<div class="scoreboard"><div><div class="kicker">' + kindName(run.type) + ' ・ '
    + (timed ? 'タイムアタック' : practicing ? '復習クイズ' : run.range.name + ' ・ エンドレス') + '</div>'
    + '<strong>' + (timed ? '30問正解にチャレンジ！　' + run.correct + ' / 30'
      : practicing ? '正解 ' + run.correct + '問' : '今現在、' + run.correct + '問正解中！') + '</strong>'
    + '　<span class="small">' + run.attempts + '問にチャレンジ</span></div>'
    + (timed ? '<div class="clock"><span class="small">タイム　</span><strong id="timer">' + formatTime(elapsed(run)) + '</strong></div>' : '')
    + button('トップへ', 'home') + '</div>';
  const choices = '<div class="choice-grid" role="group" aria-label="4つの選択肢">' + question.choices.map((choice, index) => {
    const right = response && choice.id === pref.id;
    const wrong = response && !response.correct && response.choice.id === choice.id;
    const mark = right ? '✓' : wrong ? '×' : '';
    return '<button class="choice' + (right ? ' is-correct' : wrong ? ' is-wrong' : '') + '" type="button" data-action="answer" data-value="' + choice.id
      + '" disabled><span class="choice-letter" aria-hidden="true">' + 'ABCD'[index] + '</span>'
      + ruby(choice.name, choice.reading) + (mark ? '<span class="choice-mark" aria-label="' + (right ? '正解' : '選んだ答え') + '">' + mark + '</span>' : '')
      + '</button>';
  }).join('') + '</div>';
  const feedback = response ? '<div class="feedback' + (response.correct ? '' : ' wrong') + '" id="feedback" role="status" tabindex="-1"><strong>'
    + (response.correct ? '✓ 正解！' : '× ざんねん！') + '</strong>答えは '
    + (question.type === 'capital' ? ruby(pref.capital, pref.capitalReading) : ruby(pref.name, pref.reading)) + ' です。</div>'
    + (achievements.length ? '<div class="celebrate-text" role="status">' + achievements.map(e).join('<br>') + '</div>' : '')
    + '<div class="stack compact">' + details(pref, question.attraction ?? attractions[pref.id][0]) + '</div>'
    + button(run.complete ? '結果を見る' : '次の問題へ', 'next', '', { style: 'primary next-button' }) : '';
  return '<div class="stack">' + scoreboard + '<section class="quiz-grid"><div class="panel question-panel stack compact'
    + (showMap ? ' has-map' : ' charm') + '"><h1 tabindex="-1">' + questionText(question) + '</h1>'
    + (showMap ? mapForQuestion(pref, Boolean(response), { locator: pref.region.id === 'kyushu' })
      + (response ? '<p class="small muted">赤い丸は' + (pref.id === '13' ? '都庁' : '県庁など') + 'のおよその位置です。</p>' : '') : '')
    + '</div><div class="stack compact">' + choices + feedback + '</div></section></div>';
}

export function resultScreen(result) {
  const timed = result.mode === 'time';
  const wrong = result.attempts - result.correct;
  const title = timed ? '30問クリア！' : '復習クイズの結果';
  const celebration = timed && result.record?.improved
    ? '<p class="celebrate-text">' + (result.record.first ? '初クリアおめでとう！' : '記録更新おめでとう！') + '</p>' : '';
  return '<div class="stack">' + heading(title, 'home', 'トップへ', kindName(result.type))
    + '<section class="panel stack">' + celebration
    + (timed ? '<div><p class="kicker">クリアタイム</p><p class="time-value">' + formatTime(result.ms) + '</p>'
      + '<p class="muted">最高タイム　' + formatTime(result.record.best) + '</p></div>' : '')
    + '<dl class="metrics"><div><dt>正解</dt><dd>' + result.correct + '問</dd></div><div><dt>挑戦</dt><dd>' + result.attempts
    + '問</dd></div><div><dt>不正解</dt><dd>' + wrong + '問</dd></div></dl><div class="actions">'
    + (timed && wrong ? button('間違えた問題を復習', 'review', '', { style: 'primary' }) : '')
    + (timed ? button('もう一度挑戦', 'time-setup') : button('復習一覧へ', 'review')) + button('トップへ戻る', 'home')
    + '</div></section></div>';
}

export function reviewScreen(result) {
  return '<div class="stack">' + heading('間違えた問題の復習', 'time-result', 'タイムの結果へ', kindName(result.type))
    + '<div>' + button('間違えた問題だけでもう一度クイズ', 'start', 'review', { style: 'primary' }) + '</div>'
    + '<section class="panel stack compact">' + [...result.mistakes.values()].map(({ question, count }) =>
      '<details class="review-entry" data-question="' + e(question.id) + '"><summary>' + ruby(question.prefecture.name, question.prefecture.reading)
      + (question.attraction ? ' ・ ' + ruby(question.attraction.name, question.attraction.reading) : '')
      + ' <span class="badge">' + count + '回</span></summary><div class="stack compact review-content"></div></details>').join('') + '</section></div>';
}

export function reviewEntry(mistake) {
  const { question, choices } = mistake;
  const pref = question.prefecture;
  const answer = question.type === 'capital' ? ruby(pref.capital, pref.capitalReading) : ruby(pref.name, pref.reading);
  return '<p><strong>' + questionText(question) + '</strong></p>'
    + '<p>選んだ答え　' + [...choices].map(([choice, count]) => e(choice) + (count > 1 ? '（' + count + '回）' : '')).join('、') + '</p>'
    + '<p><strong>正しい答え　' + answer + '</strong></p>'
    + mapForQuestion(pref, true)
    + details(pref, question.attraction ?? attractions[pref.id][0], true);
}

function legend(master) {
  const entries = master ? Object.values(statusStyles) : regions;
  return '<ul class="legend" aria-label="地図の色分け">' + entries.map(item =>
    '<li><span class="swatch" style="--swatch:' + item.color + '"></span>' + ruby(item.name, item.reading) + '</li>').join('') + '</ul>';
}

export function atlasMap(state, atlas, master) {
  const getFill = pref => master ? statusStyles[status(state, pref.id)].color : pref.region.color;
  return mapFrame(atlas.area, { selected: atlas.pref, interactive: true, view: atlas.view,
    canPan: atlas.zoom > 1, getFill, caption: areaLabel(atlas.area), label: areaLabel(atlas.area) + 'の都道府県地図' });
}

function prefGroups(state, atlas, master) {
  const regionList = regions.filter(region => atlas.area === 'all' || region.id === atlas.area
    || (region.id === 'kyushu' && ['amami', 'okinawa'].includes(atlas.area))
    || (region.id === 'kanto' && ['izu', 'ogasawara'].includes(atlas.area)));
  return regionList.map(region => '<section class="pref-select-section"><h3>' + ruby(region.name, region.reading) + '</h3><div class="pref-list">'
    + prefectures.filter(pref => pref.region === region).map(pref => {
      const statusItem = statusStyles[status(state, pref.id)];
      const pressed = pref.id === atlas.pref;
      const label = master ? ' aria-label="' + e(pref.name + ' ' + statusItem.name) + '"' : '';
      return button((master ? '<span aria-hidden="true">' + statusItem.mark + '</span>' : '') + ruby(pref.name, pref.reading),
        'pref', pref.id, { attributes: 'aria-pressed="' + pressed + '"' + label });
    }).join('') + '</div></section>').join('');
}

function masteredDetails(state, pref) {
  const entries = state.history[pref.id];
  const complete = typeIds.filter(type => entries?.[type]?.correct > 0).length;
  return '<p>' + (complete === 3 ? '★ マスター達成！' : 'あと' + (3 - complete) + 'つでマスター！') + '</p><ul class="status-list">'
    + typeIds.map(type => {
      const done = entries?.[type]?.correct > 0;
      return '<li><strong>' + ruby(types[type].short, types[type].shortReading) + '</strong><span class="' + (done ? 'achieved' : 'muted') + '">'
        + (done ? '✓ 達成' : '○ 未達成') + '</span>' + (done ? '' : button('この項目を練習', 'focus-practice', type)) + '</li>';
    }).join('') + '</ul>';
}

export function atlasDetails(state, atlas, master) {
  const pref = prefectureById[atlas.pref];
  if (!pref) return '<h2>気になる都道府県を選ぼう</h2><p class="muted">地図や名前を押すと、ここに' + (master ? '達成した項目' : '県の情報') + 'が出ます。</p>';
  return '<h2 tabindex="-1" id="pref-title">' + ruby(pref.name, pref.reading) + '</h2>'
    + (master ? masteredDetails(state, pref)
      : details(pref, null, true) + button('地図で位置を確かめる', 'focus-map', pref.id))
    + (pref.id === '13' ? '<div class="actions">' + button('伊豆諸島を見る', 'area', 'izu') + button('小笠原諸島を見る', 'area', 'ogasawara') + '</div>' : '')
    + (pref.id === '46' ? '<div>' + button('奄美群島などを見る', 'area', 'amami') + '</div>' : '')
    + (pref.id === '47' ? '<div>' + button('沖縄の島々を見る', 'area', 'okinawa') + '</div>' : '');
}

export function atlasScreen(state, atlas, master) {
  const { mastered, total, remaining } = summary(state);
  const overview = '<section class="panel stack compact"><p class="progress-number"><strong>' + mastered + '</strong><span>/ ' + total + ' 都道府県</span></p>'
    + meter(mastered, total) + '<p><strong>' + remainingText(remaining) + '</strong></p><div class="legend">'
    + byRegion(state).map(item => '<span class="badge">' + item.range.name + ' ' + item.mastered + ' / ' + item.total + '</span>').join('') + '</div></section>';
  return '<div class="stack">' + heading(master ? '47都道府県マスター' : ruby('都道府県一覧', 'とどうふけんいちらん'))
    + (master ? overview : '')
    + '<div class="atlas-grid"><section class="panel stack compact"><div class="map-controls"><label>地図の範囲 <select id="area" aria-label="地図の範囲">'
    + ['all', ...regions.map(r => r.id), ...islandAreas].map(id => '<option value="' + id + '"' + (atlas.area === id ? ' selected' : '') + '>' + areaLabel(id) + '</option>').join('')
    + '</select></label>' + button('＋', 'zoom', 'in', { style: 'map-control', attributes: 'aria-label="地図を拡大"' + (atlas.zoom >= 4 ? ' disabled' : '') })
    + button('−', 'zoom', 'out', { style: 'map-control', attributes: 'aria-label="地図を縮小"' + (atlas.zoom <= 1 ? ' disabled' : '') })
    + '</div>' + legend(master) + '<div class="atlas-map">' + atlasMap(state, atlas, master) + '</div><div id="pref-groups">'
    + prefGroups(state, atlas, master) + '</div></section><aside class="panel stack compact atlas-details" id="pref-details" aria-label="選んだ都道府県">'
    + atlasDetails(state, atlas, master) + '</aside></div></div>';
}

export function sourcesScreen() {
  return '<div class="stack">' + heading('教材の出典') + '<section class="panel stack"><p>地図帳でも、名前や位置を確かめてみよう。</p>'
    + '<p>地図の加工・教材作成：教材ライブラリ（nishitani-sensei）</p><ul class="stack compact">'
    + '<li>国土交通省「国土数値情報（行政区域・2026年版）」を加工。県境や海岸線を小さな画面向けに簡略化しています。'
    + '<br><a href="' + e(mapSource) + '" target="_blank" rel="noopener noreferrer">行政区域データ（外部サイト）</a> ・ '
    + '<a href="https://creativecommons.org/licenses/by/4.0/deed.ja" target="_blank" rel="noopener noreferrer">CC BY 4.0</a></li>'
    + '<li>琵琶湖は国土交通省「国土数値情報（湖沼・2005年版）」を加工して表示しています。'
    + '<br><a href="' + e(lakeSource) + '" target="_blank" rel="noopener noreferrer">湖沼データ（外部サイト・商用可）</a></li>'
    + '<li>赤い印は国土交通省「国土数値情報（国・都道府県の機関・2022年版、非商用）」を加工した庁舎のおよその位置です。'
    + '<br><a href="' + e(officeSource) + '" target="_blank" rel="noopener noreferrer">庁舎の位置（外部サイト）</a></li>'
    + '<li><a href="https://nlftp.mlit.go.jp/ksj/other/agreement_02.html" target="_blank" rel="noopener noreferrer">湖沼・庁舎データの利用規約（外部サイト）</a></li>'
    + '<li><a href="' + e(capitalSource) + '" target="_blank" rel="noopener noreferrer">全国知事会の都道府県庁所在地一覧（PDF）</a>、'
    + '<a href="' + e(tokyoSource) + '" target="_blank" rel="noopener noreferrer">東京都庁の所在地（外部サイト）</a></li>'
    + '<li>都道府県の魅力は各都道府県の詳細画面に出典を掲載しています。</li>'
    + '<li><a href="https://www.mext.go.jp/content/20230308-mxt_kyoiku02-100002607_003.pdf" target="_blank" rel="noopener noreferrer">文部科学省 小学校学習指導要領解説 社会編（PDF）</a></li></ul></section></div>';
}

export function settingsScreen() {
  return '<div class="stack">' + heading('記録の設定') + '<section class="panel stack reading-block"><p>記録は今使っているブラウザに保存されます。'
    + '共有の端末では前に使った人の記録が表示されることがあります。</p><div class="actions">'
    + button('最高タイムをリセット', 'reset', 'best') + button('マスター・学習記録をリセット', 'reset', 'progress') + '</div></section></div>';
}
