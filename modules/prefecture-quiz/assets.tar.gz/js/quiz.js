import { prefectures, inRange, national, practiceRange } from '../data/prefectures.js';
import { attractions } from '../data/attractions.js';

export const target = 30;
export const types = {
  location: { name: '都道府県の場所', reading: 'とどうふけんのばしょ', short: '場所', shortReading: 'ばしょ', icon: 'pin', note: '地図の色がついたところを当てよう。' },
  capital: { name: '県庁所在地', reading: 'けんちょうしょざいち', short: '県庁所在地', shortReading: 'けんちょうしょざいち', icon: 'flag', note: '県庁などがあるまちを当てよう。' },
  charm: { name: '都道府県の魅力', reading: 'とどうふけんのみりょく', short: '魅力', shortReading: 'みりょく', icon: 'spark', note: '名所や文化のヒントから県を当てよう。' },
};
export const typeIds = Object.keys(types);

export function shuffle(items, random = Math.random) {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index--) {
    const other = Math.floor(random() * (index + 1));
    [shuffled[index], shuffled[other]] = [shuffled[other], shuffled[index]];
  }
  return shuffled;
}

export function questionsFor(prefecture, type) {
  if (type !== 'charm') return [{ id: type + ':' + prefecture.id, type, prefecture }];
  return attractions[prefecture.id].map(attraction => ({
    id: type + ':' + prefecture.id + ':' + attraction.id, type, prefecture, attraction,
  }));
}

export function makeChoices(question, pool, random = Math.random, answerIndex = Math.floor(random() * 4)) {
  const correct = question.prefecture;
  const range = practiceRange(correct);
  const alternatives = shuffle(pool.filter(pref => pref !== correct), random);
  const nearby = alternatives.filter(pref => inRange(pref, range));
  const others = alternatives.filter(pref => !inRange(pref, range));
  const options = [...nearby.slice(0, 3), ...others, ...nearby.slice(3)].slice(0, 3);
  if (options.length !== 3) throw new Error('4択に必要な都道府県がそろっていません。');
  const choices = shuffle(options, random);
  choices.splice(answerIndex, 0, correct);
  return choices.map(pref => ({
    id: pref.id,
    name: question.type === 'capital' ? pref.capital : pref.name,
    reading: question.type === 'capital' ? pref.capitalReading : pref.reading,
  }));
}

function rotate(list, last, random) {
  const order = shuffle(list, random);
  if (order.length > 1 && order[0] === last) [order[0], order[1]] = [order[1], order[0]];
  return order;
}

export function createRun({
  type, mode, range = national, approach = 'normal', first, review = [],
  achieved = () => false, now = () => performance.now(), random = Math.random,
}) {
  const pool = prefectures.filter(pref => inRange(pref, range));
  return {
    type, mode, range, approach, first, review, achieved, now, random, pool,
    deck: [], pending: new Map(), used: new Map(), positionDeck: [], reviewPosition: 0,
    attempts: 0, correct: 0, question: null, response: null, mistakes: new Map(),
    totalMs: 0, answeringSince: null, complete: false,
  };
}

function choosePrefecture(run) {
  const previous = run.question?.prefecture;
  if (run.first) {
    const first = run.first;
    run.first = null;
    return first;
  }
  if (run.approach === 'master') {
    const available = run.pool.filter(pref => pref !== previous);
    const remaining = available.filter(pref => !run.achieved(pref.id, run.type));
    const completed = available.filter(pref => run.achieved(pref.id, run.type));
    if (run.pool.some(pref => !run.achieved(pref.id, run.type))) {
      const chooseRemaining = remaining.length > 0 && (!completed.length || run.random() < 0.7);
      const candidates = chooseRemaining ? remaining : completed;
      const fewest = Math.min(...candidates.map(pref => run.used.get(pref.id) ?? 0));
      const leastUsed = candidates.filter(pref => (run.used.get(pref.id) ?? 0) === fewest);
      return leastUsed[Math.floor(run.random() * leastUsed.length)];
    }
  }
  if (!run.deck.length) run.deck = rotate(run.pool, previous, run.random);
  return run.deck.shift();
}

function chooseQuestion(run, pref) {
  let remaining = run.pending.get(pref.id);
  if (!remaining?.length) {
    const all = questionsFor(pref, run.type);
    const order = shuffle(all, run.random);
    const lastId = remaining?.lastId;
    if (order.length > 1 && order[0].id === lastId) [order[0], order[1]] = [order[1], order[0]];
    remaining = order;
    run.pending.set(pref.id, remaining);
  }
  const question = remaining.shift();
  remaining.lastId = question.id;
  return question;
}

export function nextQuestion(run) {
  if (run.complete || (run.question && !run.response)) return null;
  let question;
  if (run.mode === 'review') {
    question = run.review[run.reviewPosition++];
    if (!question) return null;
  } else {
    const pref = choosePrefecture(run);
    run.used.set(pref.id, (run.used.get(pref.id) ?? 0) + 1);
    question = chooseQuestion(run, pref);
  }
  if (!run.positionDeck.length) run.positionDeck = shuffle([0, 1, 2, 3], run.random);
  run.question = { ...question, choices: makeChoices(question, run.pool, run.random, run.positionDeck.shift()) };
  run.response = null;
  return run.question;
}

export function resumeClock(run) {
  if (run.mode === 'time' && run.question && !run.response && !run.complete && run.answeringSince === null) {
    run.answeringSince = run.now();
  }
}

export function pauseClock(run) {
  if (run.answeringSince === null) return;
  run.totalMs += Math.max(0, run.now() - run.answeringSince);
  run.answeringSince = null;
}

export function elapsed(run) {
  return run.totalMs + (run.answeringSince === null ? 0 : Math.max(0, run.now() - run.answeringSince));
}

export function submitAnswer(run, id) {
  if (run.response || run.complete || !run.question) return null;
  const choice = run.question.choices.find(item => item.id === id);
  if (!choice) return null;
  pauseClock(run);
  const correct = run.question.prefecture.id === id;
  run.attempts++;
  if (correct) run.correct++;
  if (!correct && run.mode === 'time') {
    const miss = run.mistakes.get(run.question.id) ?? { question: run.question, count: 0, choices: new Map() };
    miss.count++;
    miss.choices.set(choice.name, (miss.choices.get(choice.name) ?? 0) + 1);
    run.mistakes.set(run.question.id, miss);
  }
  run.complete = run.mode === 'time' ? run.correct === target
    : run.mode === 'review' && run.reviewPosition === run.review.length;
  run.response = { correct, choice };
  return run.response;
}

export function formatTime(milliseconds) {
  const hundredths = Math.floor(milliseconds / 10);
  return [Math.floor(hundredths / 6000), Math.floor(hundredths / 100) % 60]
    .map(value => String(value).padStart(2, '0')).join(':')
    + '.' + String(hundredths % 100).padStart(2, '0');
}
