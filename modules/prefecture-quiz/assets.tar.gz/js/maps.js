import { geography } from '../data/geography.js';
import { prefectures, inRange, practiceRange } from '../data/prefectures.js';

export const mapSource = geography.source;
export const officeSource = geography.officeSource;
export const lakeSource = geography.lakeSource;

const captions = {
  all: '日本全体', north: '北海道・東北', hokkaido: '北海道', tohoku: '東北',
  kanto: '関東', chubu: '中部', kinki: '近畿', chugoku: '中国', shikoku: '四国',
  kyushu: '九州本土と周辺の島', amami: 'トカラ列島・奄美群島',
  okinawa: '沖縄の島々', izu: '伊豆諸島', ogasawara: '小笠原諸島',
};
export const islandAreas = ['amami', 'okinawa', 'izu', 'ogasawara'];
export const areaLabel = key => captions[key];
export const defaultView = key => [...geography.bounds[key]];

const defaultFill = '#dce7dc';
let clipSequence = 0;
export const statusStyles = {
  new: { color: '#dbe0e0', name: '未挑戦', mark: '○', reading: 'みちょうせん' },
  learning: { color: '#f1c46b', name: '学習中', mark: '◐', reading: 'がくしゅうちゅう' },
  mastered: { color: '#75bf98', name: 'マスター', mark: '★', reading: '' },
};

function contains([x, y, width, height], [px, py]) {
  return px >= x && px <= x + width && py >= y && py <= y + height;
}

export function zoomView(area, factor, previousView, selected) {
  const base = geography.bounds[area];
  const [x, y, width, height] = previousView;
  const anchor = geography.capitals[selected];
  const center = factor > 1 && anchor && contains(previousView, anchor) ? anchor : [x + width / 2, y + height / 2];
  return constrainView(area, [center[0] - base[2] / factor / 2, center[1] - base[3] / factor / 2,
    base[2] / factor, base[3] / factor]);
}

export function constrainView(area, [x, y, width, height]) {
  const [left, top, outerWidth, outerHeight] = geography.bounds[area];
  return [Math.min(Math.max(left, x), left + outerWidth - width),
    Math.min(Math.max(top, y), top + outerHeight - height), width, height];
}

function mapMarkup(key, options) {
  const {
    view = geography.bounds[key], pool = prefectures, selected, phase, interactive = false,
    canPan = false, label = captions[key], getFill, locatorAreas = [], showCapital = false,
  } = options;
  const ordered = [...pool.filter(pref => pref.id !== selected), ...pool.filter(pref => pref.id === selected)];
  const paths = ordered.map(pref => {
    const fill = getFill?.(pref) ?? defaultFill;
    const className = pref.id === selected ? 'is-' + (phase ?? 'selected') : '';
    const hit = interactive ? ' data-action="pref" data-value="' + pref.id + '"' : '';
    const name = interactive ? '<title>' + pref.name + '</title>' : '';
    return '<path class="' + className + '" fill="' + fill + '" d="' + geography.shapes[pref.id] + '"' + hit + '>' + name + '</path>';
  }).join('');
  const water = pool.some(pref => pref.id === '25')
    ? '<path class="lake-biwa" d="' + geography.lakeBiwa + '" pointer-events="none" aria-hidden="true"/>'
    : '';
  const capital = geography.capitals[selected];
  const marker = showCapital && capital && contains(view, capital)
    ? '<circle class="marker" cx="' + capital[0] + '" cy="' + capital[1] + '" r="' + Math.max(view[2], view[3]) * .018 + '"/>' : '';
  const locator = locatorAreas.map(area => {
    const [x, y, width, height] = geography.bounds[area];
    return '<rect class="locator" x="' + x + '" y="' + y + '" width="' + width + '" height="' + height + '"/>';
  }).join('');
  const clip = 'map-clip-' + ++clipSequence;
  return '<svg class="geo-map' + (interactive ? ' is-interactive' : '') + (canPan ? ' can-pan' : '') + '" role="img" aria-label="'
    + label + '" viewBox="' + view.join(' ') + '" preserveAspectRatio="xMidYMid meet"><defs><clipPath id="' + clip
    + '"><rect x="' + view[0] + '" y="' + view[1] + '" width="' + view[2] + '" height="' + view[3] + '"/></clipPath></defs>'
    + '<g clip-path="url(#' + clip + ')"><g fill-rule="evenodd">' + paths + water
    + '</g><g aria-hidden="true" pointer-events="none">' + locator + marker + '</g></g></svg>';
}

export function mapFrame(key, options = {}) {
  const label = options.label ?? captions[key];
  const caption = options.caption ?? captions[key];
  return '<figure class="map-frame' + (options.inset ? ' locator-inset' : '') + '">' + mapMarkup(key, { ...options, label })
    + (caption ? '<figcaption class="map-caption">' + caption + '</figcaption>' : '') + '</figure>';
}

export function mapForQuestion(pref, explained, { showCapital = explained, locator = false } = {}) {
  const range = pref.region.id === 'hokkaido' ? practiceRange(pref) : pref.region;
  const pool = prefectures.filter(item => inRange(item, range));
  const config = { pool, selected: pref.id, phase: explained ? 'answer' : 'highlight', showCapital };
  if (range.id === 'kyushu') {
    const main = mapFrame('kyushu', { ...config, caption: '九州本土と周辺の島' });
    const southern = mapFrame('okinawa', { ...config, label: explained ? '沖縄の島々' : '南の島々', caption: explained ? '沖縄の島々' : '南の島々' });
    const national = explained || locator
      ? mapFrame('all', { locatorAreas: ['kyushu', 'okinawa'], inset: true, caption: '日本全体での位置' })
      : '';
    return '<div class="' + (national ? 'map-with-locator' : '') + '"><div class="map-pair">' + main + southern + '</div>' + national + '</div>';
  }
  const regional = mapFrame(range.id, { ...config, caption: explained ? captions[range.id] : '',
    label: explained ? pref.name + 'の位置' : '色のついた都道府県を探す地図' });
  return locator
    ? '<div class="map-with-locator">' + regional + mapFrame('all', { locatorAreas: [range.id], inset: true, caption: '日本全体での位置' }) + '</div>'
    : regional;
}
