# 利用している外部ライブラリ

- React / React DOM — MIT License
- Lucide — ISC License
- PDF-LIB — MIT License
- Mozilla PDF.js (`pdfjs-dist`) — Apache License 2.0。配布物の `pdfjs` 以下に、PDF.js付属の文字・画像処理部品を含みます。各ディレクトリーのLICENSEもそのまま保持しています。
- Vite / TypeScript / Vitest / Testing Library / fake-indexeddb / jsdom — 各パッケージに付属するライセンス（主にMIT）。開発・検証に利用します。
- vite-plugin-pwa — MIT License
- Workbox — MIT License

スポーツのイラストとコートは、このアプリ用にSVGで作成しています。添付された設計画像そのものを画面の背景や部品には使用していません。日本語フォントは端末にあるフォントを使います。

正確なライセンス本文は `licenses` フォルダーを参照してください。
